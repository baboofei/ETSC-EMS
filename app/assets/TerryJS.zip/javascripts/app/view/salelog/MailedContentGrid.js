Ext.define('EIM.view.salelog.MailedContentGrid', {
    extend: 'Ext.grid.Panel',
    alias: 'widget.mailed_content_grid',

    title: '已寄目录列表',
    store: 'MailedContents',
    iconCls: 'ttl_grid',

    initComponent: function() {
        this.columns = [{
            header: '编号',
            dataIndex: 'id',
            width: 50
        }, {
            header: '快递公司',
            dataIndex: 'express_id',
            width: 80,
            renderer: function() {

            }
        }, {
            header: '快递单号',
            dataIndex: 'tracking_number',
            width: 80
        }, {
            header: '描述',
            dataIndex: 'detail',
            flex: 1
        }];

        this.addMailedContentButton = Ext.create('Ext.Button', {
            text: '新增寄出目录',
            iconCls: 'btn_add',
            action: 'addMailContent'
        });
        this.pagingToolbar = Ext.create('Ext.PagingToolbar', {
            store: this.store,
            displayInfo: true,
            border: 0,
            minWidth: 380
        });

        this.bbar = [this.addMailedContentButton, '-', this.pagingToolbar];

        this.callParent(arguments);
    },

    getSelectedItem: function() {
        return this.getSelectionModel().getSelection()[0];
    }
});