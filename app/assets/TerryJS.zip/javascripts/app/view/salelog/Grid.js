Ext.define('EIM.view.salelog.Grid', {
    extend: 'Ext.grid.Panel',
    alias: 'widget.salelog_grid',

    requires: 'Ext.ux.grid.FiltersFeature',

    title: '销售日志列表',
    store: 'Salelogs',
    iconCls: 'ttl_grid',

    initComponent: function() {
//        var ownerStore = Ext.data.StoreManager.lookup('Users');
        var processArray;
        var processStore = Ext.getStore("dict.SalelogProcesses").load(function() {
            processArray = Ext.pluck(processStore.data.items, 'data');
        });

        this.columns = [{
            header: '联系时间',
            width: 120,
            dataIndex: 'created_at',
            renderer: Ext.util.Format.dateRenderer("Y-m-d")
        }, {
            header: '进展描述',
            width: 75,
            dataIndex: 'process_type',
            renderer: function(value, metaData, record) {
                for(var i=0;i<processArray.length;i++){
                    if(processArray[i]["id"] === value){
                        return processArray[i]["name"];
                    }
                }
            }
        }, {
            header: '进展细节',
            flex: 1,
            dataIndex: 'detail'
        }];

        this.addSalelogButton = Ext.create('Ext.Button', {
            text: '新增销售工作日志',
            iconCls: 'btn_add',
            action: 'addSalelog',
            disabled: true
        });
        this.pagingToolbar = Ext.create('Ext.PagingToolbar', {
            store: this.store,//'Salelogs',//Ext.getStore('Salelogs'),
            displayInfo: true,
            border: 0,
            minWidth: 380
        });

        this.features = [{
            ftype: 'filters',
            encode: true
        }];

        this.bbar = [this.addSalelogButton, '-', this.pagingToolbar];

        this.callParent(arguments);
    }
});