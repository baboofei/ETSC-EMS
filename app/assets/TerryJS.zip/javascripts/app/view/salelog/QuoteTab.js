Ext.define('EIM.view.salelog.QuoteTab', {
    extend: 'Ext.form.Panel',
    alias: 'widget.quote_tab',

    title: '报价',
    border: 0,
    padding: '0 4',
//    bodyPadding: 4,
    layout: 'border',
//    fieldDefaults: EIM_field_defaults,
    items: [{
        xtype: 'salelog_quote_grid',
        region: 'west',
        padding: '5 0 0 0',
        split: true,
        width: 250
    }, {
        xtype: 'salelog_quoted_item_grid',
        region: 'center',
        padding: '5 0 0 0'
    }]
});