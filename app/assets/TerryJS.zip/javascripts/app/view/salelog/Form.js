Ext.define('EIM.view.salelog.Form', {
    extend: 'Ext.window.Window',
    alias: 'widget.salelog_form',

    title: '新增销售工作日志',
    layout: 'fit',
    width: 640,
    height: 400,
    modal: true,
    maximizable: true,
//    closeAction: 'hide',
//    resizable: false,

    initComponent: function() {
        this.items = [{
            xtype: 'container',
            layout: 'anchor',
            items: [{
                xtype: 'tabpanel',
                border: 0,
                anchor: '100% -65',
                items: [{
                    xtype: 'recommend_tab'
                }, {
                    xtype: 'mail_tab'
                }, {
                    xtype: 'quote_tab'
                }, {
                    xtype: 'contract_tab'
//                }, {
//                    xtype: 'problem_tab'
                }, {
                    xtype: 'wait_tab'
//                }, {
//                    xtype: 'change_tab'
                }, {
                    title: '个案取消',
                    xtype: 'cancel_tab'
                }, {
                    title: '其他',
                    xtype: 'form',
                    bodyPadding: 4,
                    border: 0,
                    items: [{
                        xtype: 'textfield',
                        fieldLabel: '详情',
                        labelWidth: 80,
                        labelSeparator: '：',
                        labelAlign: 'right',
                        allowBlank: false,
                        msgTarget: 'side',
                        anchor: '100%'
                    }]
                }]
            }, {
                xtype: 'salelog_extra_info'
            }]
        }];

        this.callParent(arguments);
    }
});