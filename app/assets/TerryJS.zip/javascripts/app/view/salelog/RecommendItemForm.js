Ext.define('EIM.view.salelog.RecommendItemForm', {
    extend: 'Ext.window.Window',
    alias: 'widget.recommend_item_form',

    title: '新增/修改推荐项目',
    layout: 'anchor',
    width: 400,
    height: 154,
    modal: true,
    autoShow: true,

    initComponent: function() {
        this.items = [{
            xtype: 'form',
            bodyPadding: 4,
            layout: 'anchor',
            border: 0,
            fieldDefaults: EIM_field_defaults,
            items: [{
                xtype: 'hidden',
                name: 'id'
            }, {
                xtype: 'combo',
                fieldLabel: '工厂',
                name: 'vendor_unit_id',
                store: 'VendorUnits',
                displayField: 'name',
                valueField: 'id',
                emptyText: '请输入产品的生产厂家',
                hideTrigger: true,//伪成输入框
                mode: 'remote',
                minChars: 1,
                triggerAction: 'query'
            }, {
                xtype: 'combo',
                fieldLabel: '产品',
                name: 'product_id',
                store: 'Products',
                displayField: 'model',
                valueField: 'id',
                emptyText: '请输入产品型号/名称/参数/reference号',
                hideTrigger: true,//伪成输入框
                mode: 'remote',
                minChars: 1,
                triggerAction: 'query'
            }, {
                xtype: 'textfield',
                fieldLabel: '指标',
                name: 'comment'
            }]
        }];

        this.buttons = [{
            text: '确定',
            action: 'save'
//        }, {
//            text: '新增',
//            action: 'create'
//        }, {
//            text: '修改',
//            action: 'update'
        }, {
            text: '取消',
            scope: this,
            handler: this.close
        }];

        this.callParent(arguments);
    }
});