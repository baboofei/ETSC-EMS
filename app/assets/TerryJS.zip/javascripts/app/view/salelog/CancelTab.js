Ext.define('EIM.view.salelog.CancelTab', {
    extend: 'Ext.form.Panel',
    alias: 'widget.cancel_tab',

    title: '个案取消',
    border: 0,
    padding: 4,
    layout: 'anchor',
    fieldDefaults: EIM_field_defaults,
    items: [{
        xtype: 'combo',
        fieldLabel: '取消原因',
        name: 'reason',
        store: 'dict.SalecaseCancelReasons',//[[1, "成为非目标客户"], [2, "客户觉得价格贵"], [3, "仅询价"], [4, "指标不符"], [5, "通过其他渠道"], [6, "其他"]],
        valueField: 'id',
        displayField: 'name',
        editable: false,
        allowBlank: false
    }]
});