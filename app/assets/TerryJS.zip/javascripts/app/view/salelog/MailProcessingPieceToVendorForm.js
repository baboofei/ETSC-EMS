Ext.define('EIM.view.salelog.MailProcessingPieceToVendorForm', {
    extend: 'Ext.window.Window',
    alias: 'widget.mail_processing_piece_to_vendor_form',

    title: '新增/修改寄出加工件(往工厂)',
    layout: 'anchor',
    width: 400,
    height: 208,
    modal: true,
    autoShow: true,

    initComponent: function() {
        this.items = [{
            xtype: 'form',
            bodyPadding: 4,
            layout: 'anchor',
            border: 0,
            fieldDefaults: EIM_field_defaults,
            items: [{
                xtype: 'textfield',
                fieldLabel: '型号',
                name: 'model',
                allowBlank: false
            }, {
                xtype: 'numberfield',
                fieldLabel: '数量',
                name: 'quantity',
                allowBlank: false,
                minValue: 0,
                decimalPrecision: 0
            }, {
                xtype: 'combo',
                fieldLabel: '快递公司',
                name: 'express_id',
                allowBlank: false,
                store: 'dict.Expresses',
                displayField: 'name',
                editable: false
            }, {
                xtype: 'textfield',
                fieldLabel: '快递单号',
                name: 'tracking_number',
                allowBlank: false
            }, {
                xtype: 'datefield',
                fieldLabel: '提醒时间',
                format: 'Y-m-d',
                value: Ext.Date.add(new Date(), Ext.Date.DAY, 15),
                name: 'remind_on'
            }]
        }];

        this.buttons = [{
            text: '保存',
            action: 'save'
        }, {
            text: '取消',
            scope: this,
            handler: this.close
        }];

        this.callParent(arguments);
    }
});