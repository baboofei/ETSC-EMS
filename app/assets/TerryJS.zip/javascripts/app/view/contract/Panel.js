Ext.define('EIM.view.contract.Panel', {
    extend: 'Ext.panel.Panel',
    alias: 'widget.contract_panel',

    layout: 'border',
    items: [{
        xtype: 'contract_grid',
        height: 300,
        minHeight: 200,
        maxHeight: 400,
        region: 'north',
        padding: "4 4 0 4",
//        border: 0,
        split: true
    }, {
        xtype: 'panel',
        region: 'north',
        title: 'bb',
        split: true
    }],

    initComponent: function() {
        this.callParent(arguments);
    }
});