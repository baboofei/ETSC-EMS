Ext.define('EIM.view.contract.Grid', {
    extend: 'Ext.grid.Panel',
    alias: 'widget.contract_grid',

    requires: 'Ext.ux.grid.FiltersFeature',

    title: '合同列表',
    store: 'Contracts',
    iconCls: 'ttl_grid',

    initComponent: function() {
        var ownerStore = Ext.data.StoreManager.lookup('Users');
        var me = this;
        //“合同状态”的字典项，供表格中显示和表头筛选用
        var statusArray;
        var statusStore = Ext.getStore('dict.ContractStatuses');
//        var statusStore = Ext.data.StoreManager.lookup('dict.ContractStatuses');
        statusStore.load(function() {
            //这一部分是给renderer用的
            statusArray = Ext.pluck(statusStore.data.items, 'data');
            //这一部分是给filter用的
            var options = Ext.Array.map(statusArray, function(record) {
                return [record["id"], record["name"]];
            });
            var target_col = me.getView().getHeaderCt().child('[dataIndex=status_id]');
            target_col.initialConfig.filter.options = options;
        });
        //“合同类别”的字典项，供表格中显示和表头筛选用
        var contractTypeArray;
        var contractTypeStore = Ext.getStore('dict.ContractTypes');
//        var contractTypeStore = Ext.data.StoreManager.lookup('dict.ContractTypes');
        contractTypeStore.load(function() {
            //这一部分是给renderer用的
            contractTypeArray = Ext.pluck(contractTypeStore.data.items, 'data');
            //这一部分是给filter用的
            var options = Ext.Array.map(contractTypeArray, function(record) {
                return [record["id"], record["name"]];
            });
            var target_col = me.getView().getHeaderCt().child('[dataIndex=contract_type_id]');
            target_col.initialConfig.filter.options = options;
        });

        this.columns = [{
            header: '东隆合同号',
            dataIndex: 'etsc_number',
            width: 75,
            sortable: true,
            filter: {
                type: 'string'
            }
        },{
            header: '合同摘要',
            dataIndex: 'summary',
            flex: 1,
            sortable: true,
            filter: {
                type: 'string'
            }
        },{
            header: '合同状态',
            dataIndex: 'status_id',
            width: 50,
            sortable: true,
            filter: {
                type: 'list',
                phpMode: true,
                options: []
            },
            renderer: function(value) {
                for(var i=0;i<statusArray.length;i++){
                    if(statusArray[i]["id"] === value){
                        return statusArray[i]["name"];
                    }
                }
            }
        },{
            header: '合同类别',
            dataIndex: 'contract_type_id',
            width: 75,
            sortable: true,
            filter: {
                type: 'list',
                phpMode: true,
                options: []
            },
            renderer: function(value) {
                for(var i=0;i<contractTypeArray.length;i++){
                    if(contractTypeArray[i]["id"] === value){
                        return contractTypeArray[i]["name"];
                    }
                }
            }
        },{
            header: '负责人',
            dataIndex: 'user',
            width: 50,
            sortable: true,
            filter: {
                type: 'list',
                options: Ext.Array.map(ownerStore.getRange(), function(record){
                    return [record.get("id"), record.get("name")];
                })
            },
            renderer: function(value, metaData, record){
                if(record["raw"]["user"]){
                    return record["raw"]["user"]["name"];
                }else{
                    return "";
                }
            }
        },{
            header: '客户联系人',
            dataIndex: 'customers',
            width: 200,
            sortable: false,
            renderer: function(value, metaData, record){
                if(record["raw"]["customers"]){
                    var names = [];
                    Ext.each(record["raw"]["customers"], function(v){
                        names.push(v["name"]);
                    });
                    return names.join("、");
                }else{
                    return "";
                }
            }
        },{
            header: '优先级',
            dataIndex: 'priority',
            width: 50,
            sortable: true,
            filter: {
                type: 'list',
                options: [[1, "普通"], [2, "加急"]]
            },
            renderer: function(value) {
                var array = [[1, "普通"], [2, "加急"]];
                if(value){
                    for(var i = 0; i < array.length; i++){
                        if(array[i][0] == value){
                            return array[i][1];
                        }
                    }
                }else{
                    return "";
                }
            }
        },{
            header: '成案率(%)',
            dataIndex: 'feasible',
            width: 100,
            sortable: true,
            filter: {
                type: 'numeric'
            }
        },{
            header: '提醒时间',
            dataIndex: 'remind',
            width: 100,
            sortable: true,
            filter: {
                type: 'date'
            },
            renderer: Ext.util.Format.dateRenderer("Y-m-d")
        }];

        this.addContractButton = Ext.create('Ext.Button', {
            text: '新增个案',
            iconCls: 'btn_add',
            action: 'addContract'
        });
        this.pagingToolbar = Ext.create('Ext.PagingToolbar', {
            store: this.store,
            displayInfo: true,
            border: 0,
            minWidth: 380
        });

        this.features = [{
            ftype: 'filters',
            encode: true
        }];

        this.bbar = [this.addContractButton, '-', this.pagingToolbar];

        this.callParent(arguments);
    }
});