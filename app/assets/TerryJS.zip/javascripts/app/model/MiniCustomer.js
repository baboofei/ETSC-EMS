Ext.define('EIM.model.MiniCustomer', {
    extend: 'Ext.data.Model',
    fields: [{
        name: 'id',
        type: 'int'
    }, {
        name: 'name',
        type: 'string'
    }, {
        name: 'customer_unit_name',
        type: 'string'
    }, {
        name: 'tel',
        type: 'string'
    }, {
        name: 'mobile',
        type: 'string'
    }, {
        name: 'fax',
        type: 'string'
    }]
});