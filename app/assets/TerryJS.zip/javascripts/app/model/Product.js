Ext.define('EIM.model.Product', {
    extend: 'Ext.data.Model',
    fields: [{
        name: 'id',
        type: 'int'
    }, {
        name: 'name',
        type: 'string'
    }, {
        name: 'model',
        type: 'string'
        /*
        * 这里应该还有，就是products表里的那些字段，但时间来不及了，先不写吧……
        * */
    }, {
        name: 'reference',
        type: 'string'
    }, {
        name: 'comment',
        type: 'string'
    }]
});