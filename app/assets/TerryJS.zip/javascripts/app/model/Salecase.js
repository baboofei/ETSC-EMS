Ext.define('EIM.model.Salecase', {
    extend : 'Ext.data.Model',
    fields: [{
        name: 'id',
        type: 'int'
    },{
        name: 'number',
        type: 'string'
    },{
        name: 'comment',
        type: 'string'
    },{
        name: 'start_time',
        type: 'date'
    },{
        name: 'end_time',
        type: 'date'
    },{
        name: 'user',
        type: 'string'
    },{
        name: 'customers',
        type: 'string'
    },{
        name: 'priority',
        type: 'int'
    },{
        name: 'feasible',
        type: 'int'
    },{
        name: 'remind',
        type: 'date'
    }]
});
