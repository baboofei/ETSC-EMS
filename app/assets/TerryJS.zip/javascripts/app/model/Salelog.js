Ext.define('EIM.model.Salelog', {
    extend : 'Ext.data.Model',
    fields: [{
        name: 'id',
        type: 'int'
    },{
        name: 'process_type',
        type: 'int'
    },{
        name: 'detail',
        type: 'string'
    },{
        name: 'created_at',
        type: 'date'
    }]
});
