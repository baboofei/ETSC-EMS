/**
 * 合同标签页上的controller
 */
Ext.define('EIM.controller.Contracts', {
    extend: 'Ext.app.Controller',

    stores: [
        'Contracts',
        'dict.ContractStatuses',
        'dict.ContractTypes'
    ],
    models: [
        'Contract',
        'dict.ContractStatus',
        'dict.ContractType'
    ],

    views: [
        'contract.Panel',
        'contract.Grid',
        'contract.Detail'
    ],

    init: function() {
        var me = this;
        me.control({
            'contract_grid': {
                render: this.loadContracts/*,
                itemdblclick: this.editCustomer,
                selectionchange: this.selectionChange*/
            }
        });
    },

    loadContracts: function(){
        Ext.getStore("dict.ContractStatuses").load();
//        console.log("Loaded!");
        Ext.getStore("Contracts").load();
    }
});