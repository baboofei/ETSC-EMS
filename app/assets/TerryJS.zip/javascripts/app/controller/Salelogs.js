/**
 * “新增销售工作日志“窗口上的controller
 * 这里只加载“推荐…”那一页的东西，别的页单做controller，分步加载
 */
Ext.define('EIM.controller.Salelogs', {
    extend: 'Ext.app.Controller',

    stores: [],
    models: [],

    views: ['salelog.ExtraInfo'],

//    refs: [{
//        ref: 'list',
//        selector: 'recommended_item_grid'
//    }],

    init: function() {
        var me = this;

        me.control({
            //当激活标签为“报价”时，下面的提交灰掉，而由上面的表格细节处理
            'salelog_form>container>tabpanel': {
                tabchange: function(tabPanel, newCard, oldCard, eOpts) {
                    var dialog = newCard.up("salelog_form");
                    var extra_info = dialog.down("salelog_extra_info", false);
                    if(newCard.xtype == "quote_tab") {
                        extra_info.disable();
                    }else{
                        extra_info.enable();
                    }
                }
            },
            //“确定”按钮的提交行为，要判断当前激活的是哪个标签
            'button[action=saveSalelog]': {
                click: function() {
                    var tab = Ext.ComponentQuery.query("salelog_form tabpanel")[0];
                    switch(tab.getActiveTab().xtype){
                        case "recommend_tab": {
                            //“推荐”标签的提交
                            Ext.getStore("RecommendedItems").sync();
                            return false;
                        }
                        case "mail_tab": {
                            var sub_tab = tab.down("tabpanel");
                            switch(sub_tab.getActiveTab().xtype){
                                case "mailed_sample_grid": {
                                    console.log("样品");
                                    return false;
                                }
                                case "mailed_content_grid": {
                                    console.log("目录");
                                    return false;
                                }
                                case "mailed_processing_piece_to_vendor_grid": {
                                    console.log("加工件(往工厂)");
                                    return false;
                                }
                                case "mailed_processing_piece_to_customer_grid": {
                                    console.log("加工件(往客户)");
                                    return false;
                                }
                                case "mailed_product_grid": {
                                    console.log("产品");
                                    return false;
                                }
                                default :{
                                    return false;
                                }
                            }
                            return false;
                        }
                        default :{
                            console.log("默认……………………");
                            return false;
                        }
                    }
                    tab.up("window").close();
                }
            }
        });
//    },
//
//    addRecommendedItem: function() {
//        Ext.widget('recommend_item_form').show();
//    },
//    editRecommendedItem: function() {
//        var record = this.getList().getSelectedItem();
//        var view = Ext.widget('recommend_item_form');
//        view.down('form').loadRecord(record);
    }
});

