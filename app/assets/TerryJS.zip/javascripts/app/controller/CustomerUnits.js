Ext.define('EIM.controller.CustomerUnits', {
    extend: 'Ext.app.Controller',

    stores: [
        'CustomerUnits',
//        'dict.CustomerUnitSorts',
        'dict.Cities'
    ],
    models: [
        'CustomerUnit',
//        'dict.CustomerUnitSort',
        'dict.City'
    ],

    views: [
        'customer_unit.Grid',
        'customer_unit.Form'
    ],

    refs: [{
        ref: 'grid',
        selector: 'customer_unit_grid'
    }],

    init: function() {
        var me = this;
        me.control({
            'customer_unit_grid': {
                render: this.loadCustomerUnits,
                itemdblclick: this.editCustomerUnit,
                selectionchange: this.selectionChange
            },
            'button[action=addCustomerUnit]': {
                click: this.addCustomerUnit
            }
        });
    },

    addCustomerUnit: function() {
        Ext.widget('customer_unit_form').show();
    },

    loadCustomerUnits: function() {
        Ext.getStore("CustomerUnits").load();
//        Ext.getStore("dict.Cities").load();
    },

    editCustomerUnit: function() {
        var record = this.getGrid().getSelectedCustomerUnit();
        var view = Ext.widget('customer_unit_form').show();
        view.down('form').loadRecord(record);
    },

    selectionChange: function() {

    }
});