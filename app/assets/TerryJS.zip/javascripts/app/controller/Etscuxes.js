/**
 * 自定义组件的controller
 * ExpandableCustomerUnitCombo是前面筛选客户单位，后面一个小加号弹对话框新增
 * ExpandableCustomerCombo是前面筛选客户姓名，后面一个小加号弹对话框新增
 */
Ext.define('EIM.controller.Etscuxes', {
    extend: 'Ext.app.Controller',

    views: [
        'etscux.ExpandableCustomerUnitCombo',
        'etscux.ExpandableCustomerCombo',
        'customer_unit.Form',
        'customer.Form'
    ],
    stores: [
        'dict.Leads',
        'dict.Applications',
        'dict.CustomerUnitSorts',
        'dict.Cities',
        'CustomerUnits',
        'Customers'
    ],
    models: [
        'dict.Lead',
        'dict.Application',
        'dict.CustomerUnitSort',
        'dict.City',
        'CustomerUnit',
        'Customer'
    ],

//    refs: [{
//        ref: 'zzform',
//        selector: 'form'
//    }],

    init: function() {
        var me = this;
//        Ext.ComponentQuery.query('expandable_customer_combo combo')[0].getStore()
        me.control({
            'expandable_customer_unit_combo button[text=+]': {
                render: function() {
//                    Ext.getStore("dict.Applications").load();
                },
                click: function(){
                    Ext.widget('customer_unit_form').show();
                }
            },
            'expandable_customer_combo combo': {
                beforequery: function(queryEvent, records, eOpts) {
//                    delete queryEvent.combo.lastQuery;
//                    console.log(combo.up('form').down('expandable_customer_combo', false).down('combo', false));
                    var customer_combo = queryEvent.combo;
                    var customer_unit_combo = customer_combo.up('form').down('expandable_customer_unit_combo', false).down('combo', false);
//                    console.log(customer_unit_combo.getValue());
                    customer_combo.store.load({
                        params: {
                            customer_unit_id: customer_unit_combo.getValue()
                        }
                    });
//                    console.log(records);
                },
                expand: function() {
                    return false;
                }
            },
//            'expandable_customer_unit_combo combo': {
//                select: function(combo, records, eOpts) {
//                    console.log(records);
//                    console.log(records[0].data);
////                    console.log(combo.up('form').down('expandable_customer_combo', false).down('combo', false));
//                    var customer_combo = combo.up('form').down('expandable_customer_combo', false).down('combo', false);
//                    customer_combo.getStore().load({
//                        params: {
//                            customer_unit_id: records[0].data.id
//                        }
//                    })
////                    console.log(records);
//                }
//            },
            'expandable_customer_combo button[text=+]': {
                render: function() {
                    Ext.getStore("dict.Applications").load();
                },
                click: function(){
                    Ext.widget('customer_form').show();
                }
            }
        });
    }
});