Ext.define('EIM.controller.Login', {
    extend: 'Ext.app.Controller',

    models: ['User'],
    stores: ['Users'],
    views: ['login.Form', 'login.Display'],

    refs: [{
        ref: 'loginForm',
        selector: 'form'
    }, {
        ref: 'loginButton',
        selector: 'loginform button[action=login]'
    }],

    init: function() {
        var me = this;
        if(islogin === false){
            me.loginWindow = Ext.create('widget.loginform');
            me.control({
                'loginform textfield': {
                    keypress: function(textfield, e, eOpts) {
//                        console.log(e.button === 12);
                        if(e.button === 12) {
                            this.loginsubmit();
                        }
                    }
                },
                'loginform button[action=login]': {
                    click: function(button) {
                        this.loginsubmit(button);

                    }
                }
            });
        } else {
            me.onFormSubmit();
        }
    },
    onFormSubmit: function(){
        var me = this;
        console.log(userName);
        Ext.example.msg("当前登录用户", userName);
        load_uniq_controller(me, 'Layout');
        load_uniq_controller(me, 'Users');//TODO 这个先放着，给假数据store用，不然报错。全搞好后删
        load_uniq_controller(me, 'Functions');

        Ext.widget('eim_layout', {
//            这里可以这样传参数过去
//            padding: 20
        }).show();
    },
    loginsubmit: function(button){
        var me = this;
        this.getLoginForm().form.submit({
            waitTitle: '登录中',
            waitMsg: '正在登录，请稍候……',
            url: '/login/login',
            standardSubmit: true,
            width: 200,
            method: 'POST',
            success: function(form, action) {
                me.loginWindow.destroy();
                //最后还是得这么写才能带上用户名之类
                location.reload();
//                me.onFormSubmit();
            },
            failure: function(form, action) {
                Ext.Msg.show({
                    title: '错误',
                    msg: '用户名/密码输入错误！',
                    width: 300,
                    buttons: Ext.Msg.OK,
                    animateTarget: button,
                    fn: function() {
                        Ext.ComponentQuery.query("loginform [name=reg_name]")[0].focus();
                    }
                });
                // Ext.MessageBox.alert('错误', "用户名/密码输入错误！");
//                            },
//                            params: {
//                                view: 'sencha',
//                                json: true
            }
        });
    }
});