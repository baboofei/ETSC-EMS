Ext.define('EIM.controller.salelog.mail.Contents', {
    extend: 'Ext.app.Controller',

    stores: [
        'MailedContents',
        'dict.Expresses'
    ],
    models: [
        'MailedContent'
    ],

    views: [
        'salelog.MailTab',
        'salelog.MailedContentGrid',
        'salelog.MailContentForm'
    ],

    refs: [{
        ref: 'grid',
        selector: 'mailed_content_grid'
    }],

    init: function() {
        var me = this;

        me.control({
            /**
             * 新增/修改寄目录
             */
            'button[action=addMailContent]': {
                click: this.addMailContent
            },
            'mailed_content_grid': {
                itemdblclick: this.editMailedContent
            }
        })
    },

    addMailContent: function() {
        Ext.widget('mail_content_form').show();
    },
    editMailedContent: function() {
        var record = this.getGrid().getSelectedItem();
        var view = Ext.widget('mail_content_form');
        view.down('form').loadRecord(record);
    }
});