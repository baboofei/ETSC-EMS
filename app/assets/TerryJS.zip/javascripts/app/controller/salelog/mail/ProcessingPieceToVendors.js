Ext.define('EIM.controller.salelog.mail.ProcessingPieceToVendors', {
    extend: 'Ext.app.Controller',

    stores: [
        'MailedProcessingPieceToVendors',
        'dict.Expresses'
    ],
    models: [
        'MailedProcessingPieceToVendor'
    ],

    views: [
        'salelog.MailTab',
        'salelog.MailedProcessingPieceToVendorGrid',
        'salelog.MailProcessingPieceToVendorForm'
    ],

    refs: [{
        ref: 'grid',
        selector: 'mailed_processing_piece_to_vendor_grid'
    }],

    init: function() {
        var me = this;

        me.control({
            /**
             * 新增/修改寄加工件(给工厂)
             */
            'button[action=addMailProcessingPieceToVendor]': {
                click: this.addMailProcessingPieceToVendor
            },
            'mailed_processing_piece_to_vendor_grid': {
                itemdblclick: this.editMailedProcessingPieceToVendor
            }
        });
    },

    addMailProcessingPieceToVendor: function() {
        Ext.widget('mail_processing_piece_to_vendor_form').show();
    },
    editMailedProcessingPieceToVendor: function() {
        var record = this.getGrid().getSelectedItem();
        var view = Ext.widget('mail_processing_piece_to_vendor_form');
        view.down('form').loadRecord(record);
    }
});