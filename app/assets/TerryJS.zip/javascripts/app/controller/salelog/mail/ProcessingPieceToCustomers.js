Ext.define('EIM.controller.salelog.mail.ProcessingPieceToCustomers', {
    extend: 'Ext.app.Controller',

    stores: [
        'MailedProcessingPieceToCustomers',
        'dict.Expresses'
    ],
    models: [
        'MailedProcessingPieceToCustomer'
    ],

    views: [
        'salelog.MailTab',
        'salelog.MailedProcessingPieceToCustomerGrid',
        'salelog.MailProcessingPieceToCustomerForm'
    ],

    refs: [{
        ref: 'grid',
        selector: 'mailed_processing_piece_to_customer_grid'
    }],

    init: function() {
        var me = this;

        me.control({
            /**
             * 新增/修改寄加工件(给客户)
             */
            'button[action=addMailProcessingPieceToCustomer]': {
                click: this.addMailProcessingPieceToCustomer
            },
            'mailed_processing_piece_to_customer_grid': {
                itemdblclick: this.editMailedProcessingPieceToCustomer
            }
        })
    },

    addMailProcessingPieceToCustomer: function() {
        Ext.widget('mail_processing_piece_to_customer_form').show();
    },
    editMailedProcessingPieceToCustomer: function() {
        var record = this.getGrid().getSelectedItem();
        var view = Ext.widget('mail_processing_piece_to_customer_form');
        view.down('form').loadRecord(record);
    }
});