Ext.define('EIM.controller.salelog.mail.Products', {
    extend: 'Ext.app.Controller',

    stores: [
        'MailedProducts',
        'dict.Expresses'
    ],
    models: [
        'MailedProduct'
    ],

    views: [
        'salelog.MailTab',
        'salelog.MailedProductGrid',
        'salelog.MailProductForm'
    ],

    refs: [{
        ref: 'grid',
        selector: 'mailed_product_grid'
    }],

    init: function() {
        var me = this;

        me.control({
            /**
             * 新增/修改寄产品
             */
            'button[action=addMailProduct]': {
                click: this.addMailProduct
            },
            'mailed_product_grid': {
                itemdblclick: this.editMailedProduct
            }
        })
    },

    addMailProduct: function() {
        Ext.widget('mail_product_form').show();
    },
    editMailedProduct: function() {
        var record = this.getGrid().getSelectedItem();
        var view = Ext.widget('mail_product_form');
        view.down('form').loadRecord(record);
    }
});