Ext.define('EIM.controller.salelog.QuoteItemForm', {
    extend: 'Ext.app.Controller',

    views: [
        'salelog.QuoteItemForm'
    ],

//    refs: [{
//        ref: 'list',
//        selector: 'recommended_item_grid'
//    }],

    init: function() {
        var me = this;

        me.control({

        });
    }
})