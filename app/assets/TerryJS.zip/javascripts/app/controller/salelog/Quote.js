Ext.define('EIM.controller.salelog.Quote', {
    extend: 'Ext.app.Controller',

    stores: [
        'SalelogQuotedItems'
    ],
    models: [
        'SalelogQuotedItem'
    ],

    views: [
        'salelog.QuoteTab',
        'salelog.QuotedItemGrid',
        'salelog.NewQuoteForm',
        'salelog.QuoteItemForm'
    ],

    refs: [{
        ref: 'grid',
        selector: 'salelog_quote_grid'
    }],

    init: function() {
        var me = this;

        me.control({
            'salelog_quote_grid': {
                render: this.activeQuote,
                selectionchange: function(grid, selected, eOpts){
                    //加载“报价项表格”里的数据，有参数传递
                    //并且控制“修改报价”按钮的可用与否
                    var quote_item_grid = Ext.ComponentQuery.query("salelog_quoted_item_grid")[0];
                    var edit_quote_btn = Ext.ComponentQuery.query("salelog_quote_grid button[action=editQuote]")[0];
                    if(selected.length > 0){
                        quote_item_grid.getStore().load({
                            params: {
                                myParam: 'foo'
                            }
                        });
                        edit_quote_btn.setDisabled(false);
                    }else{
                        quote_item_grid.getStore().removeAll();
                        edit_quote_btn.setDisabled(true);
                    }
                },
                itemdblclick: this.editQuote
            },
            'button[action=addQuote]': {
                click: this.addQuote
            },
            'button[action=editQuote]': {
                click: this.editQuote
            }
        });
//    },
//    editQuotedItem: function() {
//        var me = this;
//        load_uniq_controller(me, 'salelog.QuoteItemForm');
//        var record = me.getList().getSelectedItem();
//        var view = Ext.widget('quote_item_form');
//        view.down('form').loadRecord(record);
    },
    activeQuote: function() {
        //把“报价项列表”中的“新增报价项目”按钮藏起来，因为在此层面根本不能用它来新增
        var tool_bar = Ext.ComponentQuery.query("quote_tab>salelog_quoted_item_grid>toolbar")[0];
        var btn = tool_bar.child("button[action=addQuoteItem]");
        var sp = tool_bar.child("tbseparator");
        btn.setVisible(false);
        sp.setVisible(false);
        //加载store
        Ext.getStore("SalelogQuotes").load();
        //加载QuoteForm.js，以使用其中的NewQuoteForm和EditQuoteForm两个表单视图
        var me = this;
        load_uniq_controller(me, 'salelog.QuoteForm');
    },
    addQuote: function() {
        Ext.widget('salelog_new_quote_form').show();
    },
    editQuote: function() {
//        Ext.widget('salelog_edit_quote_form').show();
        var me = this;
//        console.log(me.getGrid());
        var record = me.getGrid().getSelectedItem();
        var view = Ext.widget('salelog_edit_quote_form');
        view.down('form').loadRecord(record);
//    },
//    loadQuoteItemForm: function() {
//        //加载下级表单
//        var me = this;
//        load_uniq_controller(me, 'salelog.NewQuoteItemForm');
    }
});