Ext.define('EIM.controller.salelog.Recommend', {
    extend: 'Ext.app.Controller',

    stores: [
        'RecommendedItems',
        'MailedSamples',
        'MailedContents',
        'MailedProcessingPieceToCustomers',
        'MailedProcessingPieceToVendors',
        'MailedProducts',
        'SalelogQuotedItems',
        'SalelogQuotes',
        'dict.SalecaseCancelReasons'
    ],
    models: [
        'RecommendedItem',
        'MailedSample',
        'MailedContent',
        'MailedProcessingPieceToCustomer',
        'MailedProcessingPieceToVendor',
        'MailedProduct',
        'SalelogQuotedItem',
        'SalelogQuote',
        'dict.SalecaseCancelReason'
    ],

    views: [
        'salelog.Form',
        'salelog.RecommendTab',
        'salelog.RecommendedItemGrid',
        'salelog.MailTab',
        'salelog.MailedSampleGrid',
        'salelog.MailedContentGrid',
        'salelog.MailedProcessingPieceToCustomerGrid',
        'salelog.MailedProcessingPieceToVendorGrid',
        'salelog.MailedProductGrid',
        'salelog.QuoteTab',
        'salelog.QuotedItemGrid',
        'salelog.QuoteGrid',
        'salelog.ContractTab',
//        'salelog.ProblemTab',
        'salelog.WaitTab',
//        'salelog.ChangeTab',
        'salelog.CancelTab'
    ],

    refs: [{
        ref: 'grid',
        selector: 'recommended_item_grid'
//    }, {
//        ref: 'form',
//        selector: 'recommend_item_form'
//    }, {
//        ref: 'btnCreate',
//        selector: 'recommend_item_form button[action=create]'
//    }, {
//        ref: 'btnUpdate',
//        selector: 'recommend_item_form button[action=update]'
    }],

    init: function() {
        var me = this;

        me.control({
            'button[action=addRecommendItem]': {
                click: this.addRecommendItem
            },
            'button[action=editRecommendedItem]': {
                click: this.editRecommendedItem
            },
            'recommended_item_grid': {
                // 表格被渲染时加载相应store
                // 如果是“编辑”操作，只会激活一个标签，那么别的数据就都不用加载
                render: this.activeRecommend,
                itemdblclick: this.editRecommendedItem,
                selectionchange: this.recommendedItemSelectionChange//(grid, selected, eOpts)这参数不用传，下面定义时直接写即可
            }
        });
    },

    /**
     * 新增/修改推荐产品
     */
    addRecommendItem: function() {
        var me = this;
        load_uniq_controller(me, 'salelog.RecommendForm');
        //widget里写了autoShow，不要执行回调函数的话就不用show一下了
        Ext.widget('recommend_item_form');//.show();
    },
    editRecommendedItem: function() {
        var me = this;
        load_uniq_controller(me, 'salelog.RecommendForm');
        var record = me.getGrid().getSelectedItem();
        var view = Ext.widget('recommend_item_form');
        view.down('form').loadRecord(record);
    },

    activeRecommend: function() {
        Ext.getStore("RecommendedItems").load();
    },
    recommendedItemSelectionChange:  function(grid, selected, eOpts) {
//        var root = Ext.ComponentQuery.query("salecase_tab")[0];
//        var form = Ext.ComponentQuery.query('form#salecase_info', root)[0];
        var edit_recommend_item_btn = Ext.ComponentQuery.query("recommended_item_grid button[action=editRecommendedItem]")[0];
        if(selected.length > 0){
//            form.loadRecord(selected[0]);
            edit_recommend_item_btn.setDisabled(false);
        }else{
//            form.form.reset();
            edit_recommend_item_btn.setDisabled(true);
        }
    }
});