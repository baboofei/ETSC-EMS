Ext.define('EIM.controller.salelog.QuoteForm', {
    extend: 'Ext.app.Controller',

    views: [
        'salelog.NewQuoteForm',
        'salelog.EditQuoteForm'
    ],

    init: function() {
        var me = this;

        me.control({
            //salelog_quoted_item_grid有两个，要限制一下
            'salelog_new_quote_form>salelog_quoted_item_grid': {
                render: this.loadQuoteItemForm
            },
            'button[action=addQuoteItem]': {
                click: this.addQuoteItem
            }
        });
    },
    loadQuoteItemForm: function() {
        //加载QuoteItemForm.js，以使用其中的QuoteItemForm表单视图
        var me = this;
        load_uniq_controller(me, 'salelog.QuoteItemForm');
    },

    addQuoteItem: function() {
        var me = this;
        load_uniq_controller(me, 'salelog.QuoteItemForm');
        //widget里写了autoShow，不要执行回调函数的话就不用show一下了
        Ext.widget('quote_item_form');//.show();
    }
})