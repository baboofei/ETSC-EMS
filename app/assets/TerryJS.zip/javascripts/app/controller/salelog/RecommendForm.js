/**
 * 拆开后单独加载“新增/修改推荐项目”视图用的controller
 */
Ext.define('EIM.controller.salelog.RecommendForm', {
    extend: 'Ext.app.Controller',

    stores: [
        'VendorUnits',
        'Products'
    ],
    models: [
        'VendorUnit',
        'Product'
    ],

    views: [
        'salelog.RecommendItemForm'
    ],

//    refs: [{
//        ref: 'list',
//        selector: 'recommended_item_grid'
//    }],

    init: function() {
        var me = this;

        me.control({
            'recommend_item_form button[action=save]': {
                click: this.validate
            }
        });
    },

    validate: function(button) {
        var win = button.up('window');
        var form = win.down('form', true);
//        console.log(form);
        if(Ext.isEmpty(form.getValues().vendor_unit_id) &&
            Ext.isEmpty(form.getValues().product_id) &&
            Ext.isEmpty(form.getValues().comment)) {
            Ext.example.msg("不行", EIM_multi_field_invalid);
            Ext.each(form.items.items, function(item){
                item.markInvalid(EIM_multi_field_invalid);
            });
        }else{
            Ext.each(form.items.items, function(item){
                item.clearInvalid();
            });
            var values = form.getValues();
//            this.addToStore(values);

            var id = Number(values.id);
            var store = Ext.getStore("RecommendedItems");
            if(id === "") {
                //如果没有id，说明是新增
                console.log("新增");
                store.add(values);
            }else{
                //有id，说明是编辑
                var record = Ext.ComponentQuery.query("recommended_item_grid")[0].getSelectionModel().getSelection()[0];
                record.set(values);
//                console.log(values);
//                values.id = Number(values.id);
//                store.loadRawData([values], true);
//                store.sync();
//            console.log(id);
//            console.log(store.getById(id));
//            store.getProxy().extraParams = values;
//            console.log(store);
            }
            win.close();
        }
    },

    addToStore: function(values) {
//        console.log(values);
//        console.log(values.id);
        var id = Number(values.id);
        var store = Ext.getStore("RecommendedItems");
        if(id === "") {
            //如果没有id，说明是新增
            console.log("新增");
            store.add(values);
        }else{
            //有id，说明是编辑
            console.log(values);
            values.id = Number(values.id);
            store.loadRawData([values], true);
            store.sync();
//            console.log(id);
//            console.log(store.getById(id));
//            store.getProxy().extraParams = values;
//            console.log(store);
        }
//        store.add(values);
//        store.add(values);
//        store.sync();//这一句在同步的时候执行即可

//        console.log(Ext.getStore("RecommendedItems"));
    }
})