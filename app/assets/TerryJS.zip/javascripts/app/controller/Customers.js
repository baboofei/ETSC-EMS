Ext.define('EIM.controller.Customers', {
    extend: 'Ext.app.Controller',

    stores: [
        'MiniCustomers',
        'Customers',
        'dict.Applications'
    ],
    models: [
        'MiniCustomer',
        'Customer',
        'dict.Application'
    ],

    views: [
        'customer.AddToMiniForm',
        'customer.Grid',
        'customer.Form'
    ],

    refs: [{
        ref: 'grid',
        selector: 'customer_grid'
    }],

    init: function() {
        var me = this;
        me.control({
            'customer_grid': {
                render: this.loadCustomers,
                itemdblclick: this.editCustomer,
                selectionchange: this.selectionChange
            },
            'button[action=addCustomer]': {
                click: this.addCustomer
            }
        });
    },

    addCustomer: function() {
        Ext.widget('customer_form').show();
        Ext.getStore("dict.Applications").load();
    },

    loadCustomers: function() {
//        Ext.getStore("dict.Applications").load();
        Ext.getStore("Customers").load();
    },

    editCustomer: function() {
        var record = this.getGrid().getSelectedCustomer();
        var view = Ext.widget('customer_form').show();
        Ext.getStore("dict.Applications").load();
        view.down('form').loadRecord(record);
        //boxselect里的值单独赋
//        console.log(record.data);
        var app_ids = record.data["application_ids"];
        var app_array = Ext.Array.map(app_ids.split("|"), function(value){
            return Number(value);
        });
//        console.log(app_ids);
        view.down('form').down('boxselect').setValue(app_array);
    },

    selectionChange: function() {

    }
});