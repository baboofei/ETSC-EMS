/**
 * 工作日志的store
 */
Ext.define('EIM.store.Salelogs', {
    extend: 'Ext.data.Store',
    model: 'EIM.model.Salelog',

    autoLoad: false,

    proxy: {
        type: 'ajax',
        url: '/users/fake_for_salelog',
        format: 'json',
        method: 'GET',
        reader: {
            root: 'salelogs',
            successProperty: 'success'
        },
        writer: {
            getRecordData: function(record){
                return {user: record.data}
            }
        }
    }
});