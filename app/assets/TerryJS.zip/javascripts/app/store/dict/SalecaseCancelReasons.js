Ext.define('EIM.store.dict.SalecaseCancelReasons', {
    extend: 'Ext.data.Store',
    model: 'EIM.model.dict.SalecaseCancelReason',

    autoLoad: false,

    proxy: {
        url: '/users/fake_for_salecase_cancel_reason',
        type: 'ajax',
//        format: 'json',
        method: 'GET',
        reader: {
            type: 'json',
            root: 'salecase_cancel_reasons',
            successProperty: 'success'
        }
    }
});