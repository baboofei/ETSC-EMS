Ext.define('EIM.store.dict.SalelogProcesses', {
    extend: 'Ext.data.Store',
    model: 'EIM.model.dict.SalelogProcess',

    autoLoad: false,

    proxy: {
        url: '/users/fake_for_salelog_process',
        type: 'ajax',
        format: 'json',
        method: 'GET',
        reader: {
//            type: 'json',
            root: 'salelog_processes',
            successProperty: 'success'
        }
    }
});