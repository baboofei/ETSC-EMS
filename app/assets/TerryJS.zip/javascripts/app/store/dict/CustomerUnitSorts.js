Ext.define('EIM.store.dict.CustomerUnitSorts', {
    extend: 'Ext.data.Store',
    model: 'EIM.model.dict.CustomerUnitSort',

    autoLoad: false,

    proxy: {
        url: '/users/fake_for_customer_unit_sort',
        type: 'ajax',
//        format: 'json',
        method: 'GET',
        reader: {
            type: 'json',
            root: 'customer_unit_sorts',
            successProperty: 'success'
        }
    }
});