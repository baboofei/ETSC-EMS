/**
 * 这个是产品的store，要取的JSON值见model\Product
 */
Ext.define('EIM.store.Products', {
    extend: 'Ext.data.Store',
    model: 'EIM.model.Product',

    autoLoad: false,

    proxy: {
        type: 'ajax',
        url: '/users/fake_for_customer_unit',//TODO 要改
        format: 'json',
        method: 'GET',
        reader: {
            root: 'products',
            successProperty: 'success'
        },
        writer: {
            getRecordData: function(record){
                return {user: record.data}
            }
        }
    }
});