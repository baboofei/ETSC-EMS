/**
 * 合同store
 */
Ext.define('EIM.store.Contracts', {
    extend: 'Ext.data.Store',
    model: 'EIM.model.Contract',

    autoLoad: false,

    proxy: {
        url: '/users/fake_for_contract',//TODO 要改的……
        type: 'ajax',
        format: 'json',
        method: 'GET',
        reader: {
            root: 'contracts',
            successProperty: 'success'
        },
        writer: {
            getRecordData: function(record){
                return {user: record.data}
            }
        }
    }
});