Ext.define('EIM.store.MiniCustomers', {
    extend: 'Ext.data.Store',
    model: 'EIM.model.MiniCustomer',

    autoLoad: false,

    proxy: {
        url: '/users/fake_for_mini_customer',//TODO 要改的……
        type: 'ajax',
        format: 'json',
        method: 'GET',
        reader: {
            root: 'mini_customers',
            successProperty: 'success'
        },
        writer: {
            getRecordData: function(record){
                return {user: record.data}
            }
        }
    }
});