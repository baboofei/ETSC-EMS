/**
 * 推荐项目的store
 */
Ext.define('EIM.store.RecommendedItems', {
    extend: 'Ext.data.Store',
    model: 'EIM.model.RecommendedItem',

    autoLoad: false,

    proxy: {
        type: 'ajax',
        url: '/users/fake_for_salecase',
        format: 'json',
        method: 'GET',
        reader: {
            root: 'salecases',
            successProperty: 'success'
        },
        writer: {
            getRecordData: function(record){
                //TODO 这个zzzroot要改，还不知道后面的行为是怎样，所以先不改
                return {zzzroot: record.data}
            }
        }
    }
});