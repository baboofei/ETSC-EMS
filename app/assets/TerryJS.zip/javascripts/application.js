/**
 *= require extjs4/ext-all-debug
 *= require extjs4/ext-lang-zh_CN
 *= require app
 */
