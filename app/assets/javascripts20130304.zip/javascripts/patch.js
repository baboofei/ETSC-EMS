/**
 * 反复开关tab标签后，标签里的按钮触发的窗口会变成多个重叠，数量等于开关该标签的次数
 * 于是用这个来判断一下，始终只出现一个
 * TODO 似乎是因为重复加载controller的问题，这里现在好像不再需要了，先留下吧
 * @param widget_name
 */
check_before_create = function (widget_name, eObj) {
    var all_widget = Ext.ComponentQuery.query(widget_name);
    var widget_to_show;
    if (all_widget.length > 0) {
//        console.log("第2++次");
        //第二次打开时用这个，而且参数很奇妙地会保留
        widget_to_show = all_widget[0];
    } else {
//        console.log("第1次");
        //第一次打开时用这个
        widget_to_show = Ext.widget(widget_name, eObj);
    }
    widget_to_show.show();
};

/**
 * 避免重复加载controller，先判断一下是否已经加载过了
 * @param me 外边传过来的me，不管是啥了……
 * @param controller 要加载的controller, string
 */
load_uniq_controller = function (me, controller) {
//    console.log(me);
    var controller_arr = me.application.controllers.keys;
    if (!Ext.Array.contains(controller_arr, controller)) {
        var c = me.application.getController(controller);
        c.init();
    }
};

/**
 * 过滤字典项那个大数组用
 * @param filter key的字符串
 * @return {Array} 返回过滤后的数组
 */
filter_all_dict = function(filter) {
    var array = Ext.ComponentQuery.query('functree')[0].allLL;
    var new_array = [];
    Ext.Array.each(array, function(item, index, allItems) {
        if(item['key'] === filter) {
            new_array.push(item);
        }
    });
    return new_array;
};
filter_currency = function(query) {
    var array = Ext.ComponentQuery.query('functree')[0].allCurrency;
    var new_array = [];
    switch(query)
    {
        case 1:
            Ext.Array.each(array, function(item, index, allList) {
                if(item['id'] === 1) {
                    new_array.push(item);
                }
            });
            break
        case 2:
            Ext.Array.each(array, function(item, index, allList) {
                if(item['id'] === 2) {
                    new_array.push(item);
                }
            });
            break
        case 3:
            Ext.Array.each(array, function(item, index, allList) {
                if(item['id'] === 1 || item['id'] === 2) {
                    new_array.push(item);
                }
            });
            break
        case 4:
            Ext.Array.each(array, function(item, index, allList) {
                if(item['id'] > 10) {
                    new_array.push(item);
                }
            });
            break
        case 5:
            Ext.Array.each(array, function(item, index, allList) {
                if(item['id'] === 1 || item['id'] > 10) {
                    new_array.push(item);
                }
            });
            break
        case 6:
            Ext.Array.each(array, function(item, index, allList) {
                if(item['id'] === 2 || item['id'] > 10) {
                    new_array.push(item);
                }
            });
            break
        default:
            new_array = array;
            break
    }
    return new_array;
};

/**
 * 所有form的默认参数
 * @type {Object}
 */
EIM_field_defaults = {
    labelWidth:80,
    labelAlign:'right',
    labelSeparator:'：',
    anchor:'100%',
    flex:1,
    msgTarget:'side'
};

/**
 * 需要同时校验的区域，校验未通过时的提示信息
 * @type {String}
 */
EIM_multi_field_invalid = "表单中的项目不能同时为空！";


/**
 * 修正chart组件中多种颜色时的legend图例显示颜色不对应问题
 */
Ext.override(Ext.chart.series.Pie, {
    getLegendColor:function (index) {
        var me = this;
        var store = me.chart.substore || me.chart.store;
        var record = store.getAt(index);
        return record.data.customColor || (me.colorSet && me.colorSet[index % me.colorSet.length]) || me.colorArrayStyle[index % me.colorArrayStyle.length];
    }
});

/**
 * 质保条款的正则校验
 * @type {RegExp}
 */
var term_reg = /^从(出厂|发货|到港|到货|客户验收|客户开始使用)起\d+个(月|小时)$/;
Ext.apply(Ext.form.VTypes, {
    //  vtype validation function
    term: function(val) {
        return term_reg.test(val);
    },
    termText: '输入格式不合法，格式应该为“从出厂起12个月”，或者“从客户开始使用起10000个小时”之类。'//,
});

/**
 * 付款方式的正则校验
 * @type {RegExp}
 */
var pay_mode_reg = /^(签合同时|发货前|发货后|验收后)付(([A-Z]{3})\d+|\d+(%))[\(|（](电汇|信用证|现金)[\)|）]$/;
Ext.apply(Ext.form.VTypes, {
    //  vtype validation function
    pay_mode: function(val, field) {
        var array = val.split("，");
        var passed = 0;
        var currency_array = [];
        var time_point_array =[];
        var total = 0;
        for(var i = 0; i < array.length; i++){
            //每一截分别校验
            if(pay_mode_reg.test(array[i])) {
                currency_array.push(RegExp.$3);
                time_point_array.push(RegExp.$1);
                if(RegExp.$3 == "") {
                    total += Number(RegExp.$2.substr(0,RegExp.$2.length - 1));
                }
                passed += 1;
            }else{
                return false;
            }
        }
        if(Ext.unique(currency_array).length > 1 || passed != array.length) return false;
        if(RegExp.$3 == "" && total != 100) return false;//百分比超过100%时报错
        if(Ext.unique(time_point_array).length != array.length) return false;
        return true;
    },
    pay_modeText: '输入格式不合法，格式应该为“签合同时付USD3000(信用证)”，或者“发货前付100%(电汇)”之类。'//,
    // vtype Mask property: The keystroke filter mask
    //  pay_modeMask: /[\d\s:amp]/i
});

/*************************************************************************************/

/**
 * 帮助文档里的临时浮动提示框
 * @type {example}
 */

Ext.example = function () {
    var msgCt;

    function createBox(t, s) {
        // return ['<div class="msg">',
        //         '<div class="x-box-tl"><div class="x-box-tr"><div class="x-box-tc"></div></div></div>',
        //         '<div class="x-box-ml"><div class="x-box-mr"><div class="x-box-mc"><h3>', t, '</h3>', s, '</div></div></div>',
        //         '<div class="x-box-bl"><div class="x-box-br"><div class="x-box-bc"></div></div></div>',
        //         '</div>'].join('');
        return '<div class="msg"><h3>' + t + '</h3><p>' + s + '</p></div>';
    }

    return {
        msg:function (title, format) {
            if (!msgCt) {
                msgCt = Ext.DomHelper.insertFirst(document.body, {id:'msg-div'}, true);
            }
            var s = Ext.String.format.apply(String, Array.prototype.slice.call(arguments, 1));
            var m = Ext.DomHelper.append(msgCt, createBox(title, s), true);
            m.hide();
            m.slideIn('t').ghost("t", { delay:1000, remove:true});
        },

        init:function () {
//            var t = Ext.get('exttheme');
//            if(!t){ // run locally?
//                return;
//            }
//            var theme = Cookies.get('exttheme') || 'aero';
//            if(theme){
//                t.dom.value = theme;
//                Ext.getBody().addClass('x-'+theme);
//            }
//            t.on('change', function(){
//                Cookies.set('exttheme', t.getValue());
//                setTimeout(function(){
//                    window.location.reload();
//                }, 250);
//            });
//
//            var lb = Ext.get('lib-bar');
//            if(lb){
//                lb.show();
//            }
        }
    };
}();

Ext.example.shortBogusMarkup = '<p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Sed metus nibh, ' +
    'sodales a, porta at, vulputate eget, dui. Pellentesque ut nisl. Maecenas tortor turpis, interdum non, sodales ' +
    'non, iaculis ac, lacus. Vestibulum auctor, tortor quis iaculis malesuada, libero lectus bibendum purus, sit amet ' +
    'tincidunt quam turpis vel lacus. In pellentesque nisl non sem. Suspendisse nunc sem, pretium eget, cursus a, fringilla.</p>';

Ext.example.bogusMarkup = '<p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Sed metus nibh, sodales a, ' +
    'porta at, vulputate eget, dui. Pellentesque ut nisl. Maecenas tortor turpis, interdum non, sodales non, iaculis ac, ' +
    'lacus. Vestibulum auctor, tortor quis iaculis malesuada, libero lectus bibendum purus, sit amet tincidunt quam turpis ' +
    'vel lacus. In pellentesque nisl non sem. Suspendisse nunc sem, pretium eget, cursus a, fringilla vel, urna.<br/><br/>' +
    'Aliquam commodo ullamcorper erat. Nullam vel justo in neque porttitor laoreet. Aenean lacus dui, consequat eu, adipiscing ' +
    'eget, nonummy non, nisi. Morbi nunc est, dignissim non, ornare sed, luctus eu, massa. Vivamus eget quam. Vivamus tincidunt ' +
    'diam nec urna. Curabitur velit. Lorem ipsum dolor sit amet.</p>';

//Ext.onReady(Ext.example.init, Ext.example);


// old school cookie functions
var Cookies = {};
Cookies.set = function (name, value) {
    var argv = arguments;
    var argc = arguments.length;
    var expires = (argc > 2) ? argv[2] : null;
    var path = (argc > 3) ? argv[3] : '/';
    var domain = (argc > 4) ? argv[4] : null;
    var secure = (argc > 5) ? argv[5] : false;
    document.cookie = name + "=" + escape(value) +
        ((expires == null) ? "" : ("; expires=" + expires.toGMTString())) +
        ((path == null) ? "" : ("; path=" + path)) +
        ((domain == null) ? "" : ("; domain=" + domain)) +
        ((secure == true) ? "; secure" : "");
};

Cookies.get = function (name) {
    var arg = name + "=";
    var alen = arg.length;
    var clen = document.cookie.length;
    var i = 0;
    var j = 0;
    while (i < clen) {
        j = i + alen;
        if (document.cookie.substring(i, j) == arg)
            return Cookies.getCookieVal(j);
        i = document.cookie.indexOf(" ", i) + 1;
        if (i == 0)
            break;
    }
    return null;
};

Cookies.clear = function (name) {
    if (Cookies.get(name)) {
        document.cookie = name + "=" +
            "; expires=Thu, 01-Jan-70 00:00:01 GMT";
    }
};

Cookies.getCookieVal = function (offset) {
    var endstr = document.cookie.indexOf(";", offset);
    if (endstr == -1) {
        endstr = document.cookie.length;
    }
    return unescape(document.cookie.substring(offset, endstr));
};
