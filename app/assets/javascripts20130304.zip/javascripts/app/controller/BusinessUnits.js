Ext.define('EIM.controller.BusinessUnits', {
    extend: 'Ext.app.Controller',

    stores: [
        'BusinessUnits',
//        'dict.CustomerUnitSorts',
        'dict.Cities'
    ],
    models: [
        'BusinessUnit',
//        'dict.CustomerUnitSort',
        'dict.City'
    ],

    views: [
//        'business_unit.Grid',
        'business_unit.Form'
    ],

    refs: [{
        ref: 'grid',
        selector: 'business_unit_grid'
    }],

    init: function() {
        var me = this;
        me.control({
            'customer_unit_grid': {
                render: this.loadCustomerUnits,
                itemdblclick: this.editCustomerUnit,
                selectionchange: this.selectionChange
            },
            'button[action=addCustomerUnit]': {
                click: this.addCustomerUnit
            },
            'customer_unit_form button[action=save]': {
            	click: this.saveCustomerUnit
            }
        });
    },

    addCustomerUnit: function() {
        Ext.widget('customer_unit_form').show();
    },
    
    saveCustomerUnit: function() {
//    	console.log("aa");
    	Ext.ComponentQuery.query("customer_unit_form")[0].down("form").submit({
    		url:"servlet/GetLogData?type=addcustomer_units",
    		submitEmptyText:false
		});
    },

    loadCustomerUnits: function() {
        Ext.getStore("CustomerUnits").load();
//        Ext.getStore("dict.Cities").load();
    },

    editCustomerUnit: function() {
        var record = this.getGrid().getSelectedCustomerUnit();
        var view = Ext.widget('customer_unit_form').show();
        view.down('form').loadRecord(record);
    },

    selectionChange: function() {

    }
});