Ext.define('EIM.controller.Products', {
    extend: 'Ext.app.Controller',

    stores: [
//        'Customers',
//        'dict.Applications'
    ],
    models: [
//        'Customer',
//        'dict.Application'
    ],

    views: [
        'product.MiniAddForm'
    ],

    refs: [{
//        ref: 'grid',
//        selector: 'customer_grid'
        ref: 'form',
        selector: 'product_mini_add_form'
    }],

    init: function() {
        var me = this;
        me.control({
//            'customer_grid': {
//                render: this.loadCustomers,
//                itemdblclick: this.editCustomer
//            },
//            'button[action=addCustomer]': {
//                click: this.addCustomer
//            },
//            'customer_form button[action=save]': {
//            	click: this.saveCustomer
//            },
            'product_mini_add_form button[action=save]': {
                click: this.miniSaveProduct
            },
            'product_mini_add_form [name=name]': {
                blur: this.refresh
            },
            'product_mini_add_form [name=model]': {
                blur: this.refresh
            }
        });
    },

//    addCustomer: function() {
//        Ext.widget('customer_form').show();
//        Ext.getStore("dict.Applications").load();
//    },
//    
//    saveCustomer: function() {
////    	console.log("aa");
//    	Ext.ComponentQuery.query("customer_form")[0].down("form").submit({
//    		url:"servlet/GetLogData?type=addcustomer",
//    		submitEmptyText:false
//		});
//    },
//
//    loadCustomers: function() {
////        Ext.getStore("dict.Applications").load();
//        Ext.getStore("Customers").load();
//    },
//
//    editCustomer: function() {
//        var record = this.getGrid().getSelectedCustomer();
//        var view = Ext.widget('customer_form').show();
//        Ext.getStore("dict.Applications").load();
//        view.down('form').loadRecord(record);
//        //boxselect里的值单独赋
////        console.log(record.data);
//        var app_ids = record.data["application_ids"];
//        var app_array = Ext.Array.map(app_ids.split("|"), function(value){
//            return Number(value);
//        });
////        console.log(app_ids);
//        view.down('form').down('boxselect').setValue(app_array);
//    }
    miniSaveProduct: function(button) {
        var win = button.up('window');
        var form = win.down('form', false);
        if(Ext.isEmpty(form.getValues().name) &&
            Ext.isEmpty(form.getValues().model)) {
            Ext.example.msg("不行", EIM_multi_field_invalid);
            form.down("[name=name]").markInvalid(EIM_multi_field_invalid);
            form.down("[name=model]").markInvalid(EIM_multi_field_invalid);
        }else{
            this.refresh();
            var vendor_unit_id = form.down('[name=vendor_unit_id] textfield', false);
            if(form.form.isValid() &&
                (vendor_unit_id.getValue() != vendor_unit_id.getRawValue())){
//                var values = form.getValues();
                form.form.submit({
                    url:'servlet/SalselogPostServlet?type=addProduct'
                });
                win.close();
            }
        }
    },
    
    refresh: function() {
        var form = this.getForm();
        form.down("[name=name]").clearInvalid();
        form.down("[name=model]").clearInvalid();
    }
});