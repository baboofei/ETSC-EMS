/**
 * 整体布局上的controller
 */

Ext.define('EIM.controller.Layout', {
    extend:'Ext.app.Controller',

    stores:[
        'AllDicts',
        'dict.Currencies'
    ],
    models: [
        'AllDict',
        'dict.Currency'
    ],

    views:[
        'layout.Layout'
    ],

    init:function () {
        var me = this;
        me.control({
            'tabpanel#center':{
                /**
                 * 解决标签切换时左边树节点的对应选中与否
                 * @param tabPanel
                 * @param newCard
                 * @param oldCard
                 * @param eOpts
                 */
                tabchange:function (tabPanel, newCard, oldCard, eOpts) {
                    var tree = Ext.ComponentQuery.query("functree")[0];
                    var record = tree.getRootNode().findChild('id', newCard.innerId, true);
                    if (record) {
                        tree.selectPath(record.getPath());
                    } else {
                        tree.getSelectionModel().deselectAll();
                    }
                }
            },
            'field':{
                /**
                 * 解决必填项前加标记
                 * 这里加的是“*”
                 * @param thisField
                 * @param eOpts
                 */
                beforerender:function (thisField, eOpts) {
                    if (thisField && !thisField.rendered && thisField.isFieldLabelable && thisField.fieldLabel && thisField.allowBlank == false) {
                        thisField.fieldLabel += '<span class="req" style="color:#ff0000">*</span>';
                    }
                }
            }
        });
    }
});