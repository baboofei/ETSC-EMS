Ext.define('EIM.controller.ContractCharts', {
    extend: 'Ext.app.Controller',

    stores: ['ContractCharts'],
    models: ['ContractChart'],

    views: ['contract.Chart'],

//    refs: [{
//
//    }],

    init: function() {
        var me = this;
        me.control({

        });
    }
});