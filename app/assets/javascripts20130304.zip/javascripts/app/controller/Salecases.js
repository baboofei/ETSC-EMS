/**
 * 销售个案标签页上的controller
 */
Ext.define('EIM.controller.Salecases', {
    extend:'Ext.app.Controller',

    stores:[
        'Salecases',
        'Salelogs',
        'Customers',
        'MiniCustomers',
        'dict.SalelogProcesses'
    ],
    models:[
        'Salecase',
        'Salelog',
        'Customer',
        'MiniCustomer',
        'dict.SalelogProcess'
    ],

    views:[
        'salecase.Panel',
        'salecase.Grid',
        'salelog.Grid',
        'salecase.Detail',
        'etscux.ExpandableCustomerUnitCombo',
        'etscux.ExpandableCustomerCombo',
        'customer.MiniGrid',
        'salecase.Form'
    ],

    init:function () {
        var me = this;
        me.control({
            'button[action=addSalecase]':{
                click:this.addSalecase
            },
            'button[action=addSalelog]':{
                click:this.addSalelog
            },
            'button[action=addCustomerFrom]':{
                click:this.addCustomerFrom
            },
            //个案信息修改的“确定”按钮
            'button[action=salecaseSubmit]': {
            	click: this.salecaseSubmit
            },
            //“新增个案”表单的“保存”按钮
            'salecase_form button[action=save]':{
                click:this.salecaseFormSubmit
            },
//            //“推荐产品”表单的“保存”按钮
//            'recommend_item_form button[action=save]': {
//                click: this.recommendItemSubmit
//            },
            'salecase_grid':{
                selectionchange:this.salecaseSelectionChange,//(grid, selected, eOpts)这参数不用传，下面定义时直接写即可
                render: this.clearChildStore
            },
            'salelog_grid':{
                /*render:this.loadProcessStore,
                 itemdblclick: this.editSalelog*/
            },
            'salelog_form':{
                close:function () {
//                    if(Ext.ComponentQuery.query("recommended_item_grid")) Ext.ComponentQuery.query("recommended_item_grid")[0].destroy();
//                    if(Ext.ComponentQuery.query("recommend_tab")) Ext.ComponentQuery.query("recommend_tab")[0].destroy();
//                    if(Ext.ComponentQuery.query("salelog_form")) Ext.ComponentQuery.query("salelog_form")[0].destroy();
//                    console.log("recommended_item_grid 被销毁了");
                }
            },
            'mail_tab': {
                render: this.loadMailController
            },
            'quote_tab': {
                render: this.loadQuoteController
            },
            'contract_tab': {
                render: this.loadContractController
            },
            'wait_tab': {
                render: this.loadWaitController
            }
        });
//      Ext.create("EIM.view.salecase.Layout", {
//      });
    },

    /**
     * 加载时把子表（“销售日志列表”、“联系人列表”这些）的数据清空
     * 否则当关闭再打开标签时会有加载不到字典项的错误
     * 2012-10-25
     */
    clearChildStore: function() {
        Ext.getStore('Salelogs').removeAll();
        Ext.getStore('MiniCustomers').removeAll();
    },

    addSalecase: function() {
        Ext.widget('salecase_form').show();
    },

    addSalelog:function () {
        Ext.getBody().mask("加载中，请稍候……");
        var me = this;
        load_uniq_controller(me, 'Salelogs');
        //新增销售工作日志时加载第一个标签页“推荐”的controller，其它的标签激活时再加载
        load_uniq_controller(me, 'salelog.Recommend');
//        load_uniq_controller(me, 'Salelogs');
        Ext.widget('salelog_form').show("", function () {
//            Ext.ComponentQuery.query("salelog_form>container>tabpanel")[0].items.getAt(3).setDisabled(true);
//            Ext.ComponentQuery.query("salelog_form>container>tabpanel")[0].setActiveTab(2);
        }, this);
        Ext.getBody().unmask();
    },

    addCustomerFrom:function () {
        var me = this;
        load_uniq_controller(me, 'Customers');
        Ext.widget('customer_add_to_mini_form').show();
    },

    salecaseSubmit: function(button, e, eOpts) {
    	var me = button;
    	var form = me.up('form');
    	var sale_case_id = Ext.ComponentQuery.query("salecase_grid")[0].getSelectionModel().getSelection()[0].get("id");
    	form.submit({
    		url: 'servlet/GetLogData?type=updatecase',
    		params: {
    			sale_case_id : sale_case_id
	    	},
    		submitEmptyText: false,
    		success: function(){
	    		Ext.getStore("Salecases").load();
	    	}
    	});
    },

    salecaseFormSubmit: function(button, e, eOpts) {
        var me = button;
        var form = me.up('window').down('form');
//        console.log(userId);
        form.form.submit({
            url:'servlet/GetLogData?type=5',
            params: {
        	userid: userId
        	},
    		success: function(){
	    		Ext.getStore("Salecases").load();
	    	}
        });
        me.up('window').close();
    },


    /**
     * 上面的“个案列表”里选中时，下面“个案信息”、“客户信息”、“日志列表”里加载数据
     * @param selectionModel
     * @param selected
     * @param eOpts
     */
    salecaseSelectionChange:function (selectionModel, selected, eOpts) {
        var root = Ext.ComponentQuery.query("salecase_tab")[0];
        var form = Ext.ComponentQuery.query('form#salecase_info', root)[0];
        var add_salelog_btn = Ext.ComponentQuery.query("salelog_grid button[action=addSalelog]", root)[0];
        var add_customer_btn = Ext.ComponentQuery.query("customer_mini_grid button[action=addCustomerFrom]", root)[0];
        var edit_salecase_btn = Ext.ComponentQuery.query("button[action=salecaseSubmit]")[0];
        if (selected.length > 0) {
//                        console.log(selected[0]);
            form.loadRecord(selected[0]);
            Ext.getStore('Salelogs').load({
                params:{
                    salecase_id:selected[0].get("id")
                }
            });

            Ext.getStore('MiniCustomers').load({
                params:{
                    salecase_id:selected[0].get("id")
                }
            });
            add_salelog_btn.setDisabled(false);
            add_customer_btn.setDisabled(false);
            edit_salecase_btn.setDisabled(false);
        } else {
            form.form.reset();
            Ext.getStore('Salelogs').removeAll();
            Ext.getStore('MiniCustomers').removeAll();
            add_salelog_btn.setDisabled(true);
            add_customer_btn.setDisabled(true);
            edit_salecase_btn.setDisabled(true);
        }
    },

//    editSalelog: function(grid, record, item, index, e, eOpts ){
//    },

    loadMailController:function () {
        //激活标签时加载其上的controller
        var me = this;
        load_uniq_controller(me, 'salelog.mail.Samples');
    },
    loadQuoteController:function () {
        //激活标签时加载其上的controller
        var me = this;
        load_uniq_controller(me, 'salelog.Quote');
    },
    loadContractController: function() {
        //激活标签时加载其上的controller
        var me = this;
        load_uniq_controller(me, 'salelog.Contract');
    },
    loadWaitController: function() {
        //激活标签时加载其上的controller
        var me = this;
        load_uniq_controller(me, 'salelog.Wait');
    }
});