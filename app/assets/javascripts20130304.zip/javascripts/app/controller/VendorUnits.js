Ext.define('EIM.controller.VendorUnits', {
    extend: 'Ext.app.Controller',

    stores: [
//        'CustomerUnits',
//        'dict.CustomerUnitSorts',
//        'dict.Cities'
    ],
    models: [
//        'CustomerUnit',
//        'dict.CustomerUnitSort',
//        'dict.City'
    ],

    views: [
        'vendor_unit.MiniAddForm'
    ],

//    refs: [{
//        ref: 'grid',
//        selector: 'customer_unit_grid'
//    }],

    init: function() {
        var me = this;
        me.control({
//            'customer_unit_grid': {
//                render: this.loadCustomerUnits,
//                itemdblclick: this.editCustomerUnit
//            },
//            'button[action=addCustomerUnit]': {
//                click: this.addCustomerUnit
//            },
//            'customer_unit_form button[action=save]': {
//            	click: this.saveCustomerUnit
//            }
            'vendor_unit_mini_add_form button[action=save]': {
                click: this.miniSaveVendorUnit
            }   
        });
    },

//    addCustomerUnit: function() {
//        Ext.widget('customer_unit_form').show();
//    },
//    
//    saveCustomerUnit: function() {
////    	console.log("aa");
//    	Ext.ComponentQuery.query("customer_unit_form")[0].down("form").submit({
//    		url:"servlet/GetLogData?type=addcustomer_units",
//    		submitEmptyText:false
//		});
//    },
//
//    loadCustomerUnits: function() {
//        Ext.getStore("CustomerUnits").load();
////        Ext.getStore("dict.Cities").load();
//    },
//
//    editCustomerUnit: function() {
//        var record = this.getGrid().getSelectedCustomerUnit();
//        var view = Ext.widget('customer_unit_form').show();
//        view.down('form').loadRecord(record);
//    }
    miniSaveVendorUnit: function(button) {
        var win = button.up('window');
        var form = win.down('form', false);
        if(form.form.isValid()) {
            form.form.submit({
                url:'servlet/SalselogPostServlet?type=addVendorUnits'
            });
            win.close();
        }
    }
});