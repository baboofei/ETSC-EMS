/**
 * 拆开后单独加载“新增/修改寄加工件(往工厂)”视图用的controller
 */
Ext.define('EIM.controller.salelog.mail.ProcessingPieceToVendorForm', {
    extend: 'Ext.app.Controller',

    stores: [
        'dict.Expresses'
    ],
    models: [
        'dict.Express'
    ],

    views: [
        'salelog.MailProcessingPieceToVendorForm'
    ],

//    refs: [{
//        ref: 'list',
//        selector: 'recommended_item_grid'
//    }],

    init: function() {
        var me = this;

        me.control({
            'mail_processing_piece_to_vendor_form button[action=save]': {
                click: this.validate
            },
            'mail_processing_piece_to_vendor_form button[action=update]': {
            	click: this.validate
            }
        });
    },

    validate: function(button) {
        var win = button.up('window');
        var form = win.down('form', false);
        var values = form.getValues();

        var id = Number(values.id);
        var store = Ext.getStore("MailedProcessingPieceToVendors");
        if(form.form.isValid()){
            if(button.action === "save") {
            	//新增
            	store.add(values);
            }else{
            	//修改，找出修改哪一条
        		var record = Ext.ComponentQuery.query("mailed_processing_piece_to_vendor_grid")[0].getSelectionModel().getSelection()[0];
    			record.set(values);
            }
            win.close();
        }
    }
})