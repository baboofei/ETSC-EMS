Ext.define('EIM.controller.salelog.Quote', {
    extend: 'Ext.app.Controller',

    stores: [
        'SalelogQuotedItems'
    ],
    models: [
        'SalelogQuotedItem'
    ],

    views: [
        'salelog.QuoteTab',
        'salelog.QuotedItemGrid',
        'salelog.QuoteForm',
        'salelog.QuoteItemForm'
    ],

    refs: [{
        ref: 'grid',
        selector: 'salelog_quote_grid'
    }],

    init: function() {
        var me = this;

        me.control({
            'salelog_quote_grid': {
                render: this.activeQuote,
                selectionchange: this.selectionChange,
                itemdblclick: this.editQuote
            },
            'button[action=addQuote]': {
                click: this.addQuote
            },
            'button[action=editQuote]': {
                click: this.editQuote
            }
        });
//    },
//    editQuotedItem: function() {
//        var me = this;
//        load_uniq_controller(me, 'salelog.QuoteItemForm');
//        var record = me.getList().getSelectedItem();
//        var view = Ext.widget('quote_item_form');
//        view.down('form').loadRecord(record);
    },
    activeQuote: function() {
        //把“报价项列表”中的“新增报价项目”和“修改报价项目”按钮藏起来，因为在此层面根本不能用它来新增
        var tool_bar = Ext.ComponentQuery.query("quote_tab>salelog_quoted_item_grid>toolbar")[0];
        var btn = tool_bar.child("button[action=addQuoteItem]");
        var btn2 = tool_bar.child("button[action=editQuoteItem]");
        var sp = tool_bar.child("tbseparator");
        btn.setVisible(false);
        btn2.setVisible(false);
        sp.setVisible(false);
        //加载store
        Ext.getStore("SalelogQuotes").load();
        //加载QuoteForm.js，以使用其中的NewQuoteForm和EditQuoteForm两个表单视图
        var me = this;
        load_uniq_controller(me, 'salelog.QuoteForm');
    },
    addQuote: function() {
        var view = Ext.widget('salelog_quote_form').show();
//        var btn_save = view.down('button[action=save]', false);
//        var btn_updt = view.down('button[action=update]', false);
//        btn_save.show();
//        btn_updt.hide();
    },
    editQuote: function() {
//        Ext.widget('salelog_edit_quote_form').show();
        var me = this;
//        console.log(me.getGrid());
        var record = me.getGrid().getSelectedItem();
        var view = Ext.widget('salelog_quote_form');
//        var btn_save = view.down('button[action=save]', false);
//        var btn_updt = view.down('button[action=update]', false);
//        btn_save.hide();
//        btn_updt.show();
//        view.down('form').loadRecord(record);
//    },
//    loadQuoteItemForm: function() {
//        //加载下级表单
//        var me = this;
//        load_uniq_controller(me, 'salelog.NewQuoteItemForm');
    },
    selectionChange: function(selectionModel, selected, eOpts){
        //加载“报价项表格”里的数据，有参数传递
        //并且控制“修改报价”按钮的可用与否
        var quote_item_grid = Ext.ComponentQuery.query("salelog_quoted_item_grid")[0];
        var edit_btn = this.getGrid().down("[iconCls=btn_edit]");
        if(selected.length > 0){
            quote_item_grid.getStore().load({
                params: {
                    myParam: 'foo'
                }
            });
            edit_btn.setDisabled(false);
        }else{
            quote_item_grid.getStore().removeAll();
            edit_btn.setDisabled(true);
        }
    }
});