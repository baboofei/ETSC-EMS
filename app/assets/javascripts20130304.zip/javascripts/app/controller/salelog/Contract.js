Ext.define('EIM.controller.salelog.Contract', {
    extend: 'Ext.app.Controller',

    stores: [
//        'SalelogQuotedItems'
    ],
    models: [
//        'SalelogQuotedItem'
    ],

    views: [
//        'salelog.ContractTab',
//        'salelog.QuotedItemGrid',
//        'salelog.NewQuoteForm',
//        'salelog.QuoteItemForm'
    ],

//    refs: [{
//        ref: 'grid',
//        selector: 'salelog_quote_grid'
//    }],

    init: function() {
        var me = this;

        me.control({

        });
    }
});