Ext.define('EIM.controller.contract.DivideSendingForm', {
    extend:'Ext.app.Controller',

    stores:[
    ],
    models:[
    ],

    views:[
        'contract.DivideSendingForm'
    ],

    init:function () {
        var me = this;

        me.control({
            'divide_sending_form button[action=save]': {
                click: this.divideSendingSubmit
            }
        });
    },

    divideSendingSubmit: function(button) {
        Ext.example.msg('注意', '这里提交到后台拆分');
        var win = button.up('window');
        var form = win.down('form', false);
        if(form.form.isValid()) {
            form.form.submit({
                url: 'divide'
            })
        }
    }
});