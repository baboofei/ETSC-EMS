Ext.define('EIM.controller.BusinessContacts', {
    extend: 'Ext.app.Controller',

    stores:[
        'BusinessContacts'
    ],
    models:[
        'BusinessContact'
    ],

    views:[
//        'business_contact.Grid',
        'business_contact.Form'
    ],

    refs:[
        {
            ref:'grid',
            selector:'business_contact_grid'
        }
    ],

    init:function () {
        var me = this;
        me.control({
            'business_contact_grid': {
                render: this.loadBusinessContacts,
                itemdblclick: this.editBusinessContact,
                selectionchange: this.selectionChange
            },
            'button[action=addBusinessContact]': {
                click: this.addBusinessContact
            },
            'business_contact_form button[action=save]': {
            	click: this.saveBusinessContact
            }
        });
    },

    addBusinessContact: function() {
        Ext.widget('business_contact_form').show();
    },

    saveBusinessContact: function() {
//    	console.log("aa");
    	Ext.ComponentQuery.query("business_contact_form")[0].down("form").submit({
    		url:"servlet/GetLogData?type=addbusiness_contact",
    		submitEmptyText:false
		});
    },

    loadBusinessContacts: function() {
//        Ext.getStore("dict.Applications").load();
        Ext.getStore("BusinessContacts").load();
    },

    editBusinessContact: function () {
        var record = this.getGrid().getSelectedItem();
        var view = Ext.widget('business_contact_form').show();
        Ext.getStore("dict.Applications").load();
        view.down('form').loadRecord(record);
    },

    selectionChange: function() {

    }
});