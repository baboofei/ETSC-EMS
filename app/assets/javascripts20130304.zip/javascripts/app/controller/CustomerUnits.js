Ext.define('EIM.controller.CustomerUnits', {
    extend: 'Ext.app.Controller',

    stores: [
        'CustomerUnits',
        'dict.CustomerUnitSorts',
        'dict.Cities',
        'GridCustomerUnits'
    ],
    models: [
        'CustomerUnit',
        'dict.CustomerUnitSort',
        'dict.City',
        'GridCustomerUnit'
    ],

    views: [
        'customer_unit.Grid',
        'customer_unit.Form'
    ],

    refs: [{
        ref: 'grid',
        selector: 'customer_unit_grid'
    }],

    init: function() {
        var me = this;
        me.control({
            'customer_unit_grid': {
                render: this.loadCustomerUnits,
                itemdblclick: this.editCustomerUnit,
                selectionchange: this.selectionChange
            },
            'button[action=addCustomerUnit]': {
                click: this.addCustomerUnit
            },
            'customer_unit_form button[action=save]': {
            	click: this.saveCustomerUnit
            }
        });
    },

    addCustomerUnit: function() {
        Ext.widget('customer_unit_form').show();
    },
    
    saveCustomerUnit: function(button) {
        var win = button.up('window');
        var form = win.down('form', false);
    	form.submit({
    		url: "servlet/GetLogData?type=addcustomer_units",
    		submitEmptyText:false,
    		success: function(form, action) {
    	        //如果保存的时候，下面有带加号的客户单位选择组件，则把值回填到其中
    	        if(Ext.ComponentQuery.query("expandable_customer_unit_combo")[0]) {
        	        var response = action.response;
        	        var text = response.request.options.params.name;
        	        Ext.ComponentQuery.query("expandable_customer_unit_combo combo")[0].setValue(text);
        	        Ext.ComponentQuery.query("expandable_customer_unit_combo combo")[0].store.load(
    	                {
    	                    params: {
    	                        query: text
                            },
                            callback : function(records, operation, success) {
                                Ext.ComponentQuery.query("expandable_customer_unit_combo combo")[0].setValue(records[0]["data"]["id"]);
                                //如果有带加号的客户选择组件，则为其加一个过滤参数
                                var expand = Ext.ComponentQuery.query("expandable_customer_combo")[0];
                                if(expand) {
                                    var customer_combo = expand.down('combo', false);
                                    customer_combo.getStore().getProxy().extraParams['customer_unit_id'] = records[0]["data"]["id"];
                                }
                            }
    	                }
                    );
    	        }
    	        win.close();
    	        Ext.getStore('GridCustomerUnits').load();
    	    }
	});
    },

    loadCustomerUnits: function() {
        Ext.getStore("CustomerUnits").load();
//        Ext.getStore("dict.Cities").load();
    },

    editCustomerUnit: function() {
        var record = this.getGrid().getSelectedCustomerUnit();
        var view = Ext.widget('customer_unit_form').show();
        view.down('form').loadRecord(record);
        //给combo做一个假的store以正确显示值
        var city_field = view.down('[name=city_id]', false);
        city_field.getStore().loadData([[record.get('city_id'), record.get('city_name')]]);
        city_field.setValue(record.get('city_id'));
    },

    selectionChange: function() {

    }
});