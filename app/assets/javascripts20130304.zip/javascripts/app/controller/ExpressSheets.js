/**
 * 打印页面上的controller
 */
Ext.define('EIM.controller.ExpressSheets', {
    extend: 'Ext.app.Controller',

    stores: [
        'ExpressCustomers',
        'dict.Applications',
        'dict.Areas',
        'ComboOurCompanies'
    ],
    models: [
        'ExpressCustomer',
        'dict.Application',
        'dict.Area',
        'ComboOurCompany'
    ],

    views: [
        'express_sheet.Panel',
        'express_sheet.SearchGrid'
    ],

    init: function() {
        var me = this;
        me.control({
            'express_sheet_search_grid[name=source_grid]': {
                beforeselect: this.filterDrag
            },
            'express_sheet_search_grid[name=source_grid] > gridview': {
            },
            'express_sheet_search_grid[name=target_grid]': {
                selectionchange: this.selectionChange
            },
            'button[action=deleteSelection]': {
                click: this.deleteSelection
            },
            'button[action=submit]': {
                click: this.submit
            }
        });
    },

    /**
     * 选择的时候过滤一下，如果下面store里已经有了就不让选，避免拖拽的时候产生ID重复的问题
     * @param rowModel
     * @param record
     * @param index
     * @param eOpts
     * @return {Boolean}
     */
    filterDrag: function(rowModel, record, index, eOpts) {
        var target_grid = Ext.ComponentQuery.query('express_sheet_search_grid[name=target_grid]')[0];
        var target_id_array = Ext.Array.pluck(target_grid.getStore().data.items, 'internalId');
        for(var i = 0; i < target_id_array.length; i ++) {
            if(record.get('id') === target_id_array[i]) {
                return false;
            }
        }
    },

    selectionChange: function(selectionModel, selected, eOpts) {
        var btn_delete = Ext.ComponentQuery.query('express_sheet_panel button[action=deleteSelection]')[0];
        if(selected.length > 0) {
            btn_delete.enable();
        }else{
            btn_delete.disable();
        }
    },

    deleteSelection: function(button) {
        var grid = button.up('grid');
        var se = grid.getSelectionModel().getSelection();
        grid.getStore().remove(se);
    },

    submit: function(button) {
        var form = button.up('form');
        var grid = form.up('panel').down('[name=target_grid]', false);
        var target_customer_ids = Ext.Array.pluck(Ext.Array.pluck(grid.getStore().data.items, "data"), "id");
        var target_customer_ids_str = target_customer_ids.join("|");

        var express_id = form.down('[name=express_id]', false).getValue();
        var our_company_id = form.down('[name=our_company_id]', false).getValue();

        if(target_customer_ids.length === 0){
            Ext.example.msg("错误", "表格中还没有数据！");
        }else{
            if(form.form.isValid()) {
                Ext.Ajax.request({
                    url:'/xxxyyy',
                    params: {
                        customer_ids: target_customer_ids_str,
                        express_id: express_id,
                        our_company_id: our_company_id
                    },
                    success: function(response) {

                    },
                    failure: function() {

                    }
                });
            }
        }
    }
});