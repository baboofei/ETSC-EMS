/**
 * 自定义组件的controller
 * ExpandableCustomerUnitCombo是前面筛选客户单位，后面一个小加号弹对话框新增
 * ExpandableCustomerCombo是前面筛选客户姓名，后面一个小加号弹对话框新增
 * ExpandableVendorUnitCombo是前面筛选工厂，后面一个小加号弹对话框新增
 * ExpandableProductCombo是前面筛选产品，后面一个小加号弹对话框新增
 * ExpandableBusinessUnitCombo是前面筛选进出口公司，后面一个小加号弹对话框新增
 * ExpandableBusinessContactCombo是前面筛选进出口公司联系人，后面一个小加号弹对话框新增
 */
Ext.define('EIM.controller.Etscuxes', {
    extend: 'Ext.app.Controller',
    stores: [
        'dict.Leads',
        'dict.Applications',
        'dict.CustomerUnitSorts',
        'dict.Cities',
        'CustomerUnits',
        'Customers',
        'VendorUnits',
        'Products',
        'BusinessUnits',
        'BusinessContacts',
        'dict.Currencies'
    ],
    models: [
        'dict.Lead',
        'dict.Application',
        'dict.CustomerUnitSort',
        'dict.City',
        'CustomerUnit',
        'Customer',
        'VendorUnit',
        'Product',
        'BusinessUnit',
        'BusinessContact',
        'dict.Currency'
    ],
    views: [
        'etscux.ExpandableCustomerUnitCombo',
        'etscux.ExpandableCustomerCombo',
        'etscux.ExpandableVendorUnitCombo',
        'etscux.ExpandableProductCombo',
        'etscux.ExpandableBusinessUnitCombo',
        'etscux.ExpandableBusinessContactCombo',
        'etscux.AmountWithCurrency',
        'customer_unit.Form',
        'customer.Form',
        'vendor_unit.MiniAddForm',
        'product.MiniAddForm',
        'business_unit.Form',
        'business_contact.Form'
    ],
//    refs: [{
//        ref: 'zzform',
//        selector: 'form'
//    }],

    init: function() {
        var me = this;
//        Ext.ComponentQuery.query('expandable_customer_combo combo')[0].getStore()
        me.control({
            /**
             * 客户和客户单位的组
             * 客户单位的输入下拉框，每次选择后把参数赋给客户的下拉框
             */
            'expandable_customer_unit_combo combo': {
                select: this.addParamsToCustomerStore
            },
            /**
             * 客户单位的小加号按钮
             */
            'expandable_customer_unit_combo button[text=+]': {
                click: this.popupFormAndSetValue
            },
            /**
             * 客户的下拉框，每次清空之前的值
             */
            'expandable_customer_combo combo': {
                beforequery: function(queryEvent, records, eOpts) {
                    delete queryEvent.combo.lastQuery;
                }
            },
            /**
             * 客户的小加号按钮
             */
            'expandable_customer_combo button[text=+]': {
                render: function() {
                    Ext.getStore("dict.Applications").load();
                },
                click: this.popUpFormAndSetCustomerUnitValue
            },

            /**
             * 生产厂家和产品的组
             * 生产厂家的输入下拉框，每次选择后把参数赋给产品的下拉框
             */
            'expandable_vendor_unit_combo combo': {
                select: function(combo, records, eOpts) {
                    var product_field = combo.up('form').down('expandable_product_combo', false);
                    if(product_field){
                        var product_combo = product_field.down('combo', false);
                        product_combo.getStore().getProxy().extraParams['vendor_unit_id'] = records[0]["data"]["id"];
                        product_combo.reset();
                    }
                }
            },
            /**
             * 生产厂家的小加号按钮
             */
            'expandable_vendor_unit_combo button[text=+]': {
                click: function() {
                    var me = this;
                    load_uniq_controller(me, 'VendorUnits');
                    Ext.widget('vendor_unit_mini_add_form').show();
                }
            },
            /**
             * 产品的下拉框，每次清空之前的值
             */
            'expandable_product_combo combo': {
                beforequery: function(queryEvent, records, eOpts) {
                    delete queryEvent.combo.lastQuery;
                }
            },
            /**
             * 产品的小加号按钮
             */
            'expandable_product_combo button[text=+]': {
                click: function() {
                    var me = this;
                    load_uniq_controller(me, 'Products');
                    Ext.widget('product_mini_add_form').show();
                }
            },

            /**
             * 进出口公司和进出口公司联系人的组
             * 进出口公司的输入下拉框，每次选择后把参数赋给进出口公司联系人的下拉框
             */
            'expandable_business_unit_combo combo': {
                select: function(combo, records, eOpts) {
                    var expandable_combo = combo.up('form').down('expandable_business_contact_combo', false);
                    if(expandable_combo) {
                        var business_combo = expandable_combo.down('combo', false);
                        business_combo.getStore().getProxy().extraParams['business_unit_id'] = records[0]["data"]["id"];
                    }
                }
            },
            'expandable_business_unit_combo button[text=+]':{
                render: function() {
                },
                click: function() {
                    var me = this;
                    load_uniq_controller(me, 'BusinessUnits');
                    Ext.widget('business_unit_form').show();
                }
            },
            'expandable_business_contact_combo combo':{
                beforequery: function(queryEvent, records, eOpts) {
                    delete queryEvent.combo.lastQuery;
                }
            },
            'expandable_business_contact_combo button[text=+]':{
                render: function() {
                },
                click: function() {
                    var me = this;
                    load_uniq_controller(me, 'BusinessContacts');
                    Ext.widget('business_contact_form').show();
                }
            },


            /**
             * 币种的下拉框，当它有值时，后面的数字框也必须有值
             */
            'amount_with_currency combo':{
                blur: this.validateCurrencyComponentCombo
            },
            /**
             * 金额的输入框，当它有值时，前面的下拉框也必须有值
             */
            'amount_with_currency numberfield':{
                blur: this.validateCurrencyComponentNumber
            }
        });
    },

    /**
     * 如果有客户下拉框在同一表单内(比如本身就是“新增客户”的表单，则不会有选择客户的下拉框)，
     * 则给此客户下拉框加一个参数：当前选中客户单位ID
     * TODO
     * 如果有“地址”在同一表单内，则要把返回的地址填进去作为默认值。但后台现在没有返回“地址”的项
     */
    addParamsToCustomerStore: function(combo, records, eOpts) {
        var expand = combo.up('form').down('expandable_customer_combo', false)
        if(expand){
            var customer_combo = expand.down('combo', false);
            customer_combo.getStore().getProxy().extraParams['customer_unit_id'] = records[0]["data"]["id"];
        }
    },
    
    /**
     * 弹出“新增客户单位”的表单，并把已经填的值放进表单里
     */
    popupFormAndSetValue: function(button){
        var me = this;
        var value = button.up('expandable_customer_unit_combo').down('combo').getRawValue();
        load_uniq_controller(me, 'CustomerUnits');
        //把已经填的值带给弹出的窗口
        var form = Ext.widget('customer_unit_form');
        form.show('', function(){
            var name = form.down('[name=name]');
            name.setValue(value);
        });
    },
    
    /**
     * 弹出“新增客户”的表单，并视情况把已经填的客户单位的值放进表单里
     */
    popUpFormAndSetCustomerUnitValue: function(button){
        var me = this;
        load_uniq_controller(me, 'Customers');
        var form = Ext.widget('customer_form');
        form.show('', function() {
            var expand_customer_unit = button.up('form').down('expandable_customer_unit_combo');
            if(expand_customer_unit) {
                var combo = expand_customer_unit.down('combo')
                if(combo.getValue() === combo.getRawValue()) {
                    //如果两个值相等，说明是个假值(还没有这个单位)，则弹出的表单里不预填写
                }else{
                    //否则把单位的值传过去
                    var target_combo = form.down('expandable_customer_unit_combo').down('combo');
                    target_combo.setValue(combo.getValue());
                }
            }
        });
    },

    validateCurrencyComponentCombo: function(combo, e, eOpts) {
        var me = this;
        var numberfield = combo.up('amount_with_currency').down('numberfield', false);

        me.validateCurrencyComponent(combo, numberfield);
    },
    validateCurrencyComponentNumber: function(numberfield, e, eOpts) {
        var me = this;
        var combo = numberfield.up('amount_with_currency').down('combo', false);

        me.validateCurrencyComponent(combo, numberfield);
    },
    /**
     * 不管blur的是哪个，都对此组件进行校验
     * @param combo
     * @param numberfield
     */
    validateCurrencyComponent: function(combo, numberfield) {
        if(combo.allowBlank === false) {
            //设定了不能为空
            if(combo.getValue() === null || combo.getValue() === 0) combo.markInvalid("此项值不能为空！");
            if(numberfield.getValue() === null || numberfield.getValue() === 0) {
                numberfield.markInvalid("此项值不能为空！");
                numberfield.setValue("");//防止是“0”的时候被validate通过而提交
            }
        }else{
            if ((combo.getValue() != null || combo.getValue() != 0) && numberfield.getValue() === null) {
                numberfield.markInvalid("有币种时必须填写金额！");
            } else {
                numberfield.clearInvalid();
            }
            if (numberfield.getValue() != null && numberfield.getValue() != 0 && combo.getValue() === null) {
                combo.markInvalid("有金额时必须填写币种！");
            } else {
                combo.clearInvalid();
            }
        }
    }
});