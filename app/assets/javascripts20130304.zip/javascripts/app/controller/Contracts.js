/**
 * 合同标签页上的controller
 */
Ext.define('EIM.controller.Contracts', {
    extend:'Ext.app.Controller',

    stores:[
        'Contracts',
        'dict.ContractStatuses',
        'dict.ContractTypes',
        'dict.RequirementSorts',
//        'dict.Currencies',
        'dict.SendStatuses',
        'dict.CheckAndAcceptStatuses',
        'Terms',
        'PayModes',
        'ContractItems',
        'ContractHistories',
        'Collections',
        'Receivables'
    ],
    models:[
        'Contract',
        'dict.ContractStatus',
        'dict.ContractType',
        'dict.RequirementSort',
//        'dict.Currency',
        'dict.SendStatus',
        'dict.CheckAndAcceptStatus',
        'Term',
        'ContractItem',
        'ContractHistory',
        'Collection',
        'Receivable'
    ],

    views:[
        'contract.Panel',
        'contract.Grid',
        'contract.Detail',
        'contract.Content',
//        'etscux.AmountWithCurrency',
//        'etscux.ExpandableBusinessContactCombo',
        'contract.ItemGrid',
        'contract.ItemForm',
        'contract.HistoryGrid',
        'contract.CollectionPanel',
        'contract.CollectionGrid',
        'contract.ReceivableGrid'
    ],

    refs:[
        {
            ref: 'grid',
            selector: 'contract_grid'
        },
        {
            ref:'itemGrid',
            selector:'contract_item_grid'
        },
        {
            ref:'collectionGrid',
            selector:'contract_collection_grid'
        },
        {
            ref:'receivableGrid',
            selector:'contract_receivable_grid'
        }
    ],

    init:function () {
        var me = this;
        me.control({
            'contract_grid': {
                render:this.loadContracts/*,
                 itemdblclick: this.editCustomer,
                 selectionchange: this.selectionChange*/
            },
            'contract_detail tabpanel': {
                tabchange: this.detailTabChange
            },
            'contract_item_grid': {
                selectionchange: this.selectionChange,
                itemdblclick: this.editContractItem
            },
            'contract_item_grid button[action=addContractItem]': {
                click: this.addContractItem
            },
            'contract_item_grid button[action=editContractItem]': {
                click: this.editContractItem
            },
            'contract_item_grid button[action=divideSending]': {
                click: this.divideSending
            },
            '[action=batchEditContractItem]>menu': {
                show: this.resetAllSubMenus
            },
            'menuitem[action=quantity] button': {
                click: this.batchEditQuantity
            },
            'menuitem[action=send_status] button': {
                click: this.batchEditSendStatus
            },
            'menuitem[action=check_and_accept_status] button': {
                click: this.batchEditCheckAndAcceptStatus
            },
            'menuitem[action=term]': {
                click: this.batchEditTerm
            },
            'menuitem[action=divide_sending] button': {
                click: this.batchEditDivideSending
            },
            'menuitem[action=expected_leave_factory] datepicker': {
                select: this.batchEditExpectedLeaveFactory
            },
            'menuitem[action=appointed_leave_factory] datepicker': {
                select: this.batchEditAppointedLeaveFactory
            },
            'menuitem[action=actually_leave_factory] datepicker': {
                select: this.batchEditActuallyLeaveFactory
            },
            'menuitem[action=leave_etsc] datepicker': {
                select: this.batchEditLeaveEtsc
            },
            'menuitem[action=reach_customer] datepicker': {
                select: this.batchEditReachCustomer
            },
            'menuitem[action=check_and_accept] datepicker': {
                select: this.batchEditCheckAndAccept
            },
            'contract_receivable_grid button[action=addReceivable]': {
                click: this.addReceivable
            },
            'contract_receivable_grid button[action=editReceivable]': {
                click: this.editReceivable
            },
            'contract_receivable_grid': {
                selectionchange: this.receivableSelectionChange,
                itemdblclick: this.editReceivable
            },
            'contract_collection_grid button[action=addCollection]': {
                click: this.addCollection
            },
            'contract_collection_grid button[action=editCollection]': {
                click: this.editCollection
            },
            'contract_collection_grid': {
                selectionchange: this.collectionSelectionChange,
                itemdblclick: this.editCollection
            }
        });
    },

    loadContracts:function () {
        Ext.getStore("dict.ContractStatuses").load();
        Ext.getStore("dict.ContractTypes").load();
        Ext.getStore("dict.RequirementSorts").load();
//        console.log("Loaded!");
        Ext.getStore("Contracts").load();
    },

    /**
     * 当切换不同标签时，切换下面的“确定”按钮可用与否，因为“合同项”或者“收款”这样的修改是直接在表格内就提交了的
     * @param tabPanel
     * @param newCard
     * @param oldCard
     * @param eOpts
     */
    detailTabChange: function(tabPanel, newCard, oldCard, eOpts) {
        var btn = Ext.ComponentQuery.query('contract_panel button[action=submit]')[0];
        if(newCard.xtype === "contract_content") {
            btn.setDisabled(false);
        }else{
            btn.setDisabled(true);
        }
    },

    selectionChange: function(selectionModel, selected, eOpts) {
        var grid = this.getItemGrid();
        var edit_btn = grid.down("[action=editContractItem]");
        var divide_btn = grid.down("[action=divideSending");
        var batch_edit_btn = grid.down("[action=batchEditContractItem]");

        //多于一个时“批量修改”才可用
        batch_edit_btn.setDisabled(selected.length <= 1);
        //只选中一个时“修改”、“分批发货”可用
        edit_btn.setDisabled(selected.length != 1);
        divide_btn.setDisabled(selected.length != 1);
    },

    addContractItem: function() {
        var me = this;
        load_uniq_controller(me, 'contract.ItemForm');
        var view = Ext.widget('contract_item_form').show();
        var btn_save = view.down('button[action=save]', false);
        var btn_updt = view.down('button[action=update]', false);
        btn_save.show();
        btn_updt.hide();
    },

    editContractItem: function() {
        var me = this;
        load_uniq_controller(me, 'contract.ItemForm');
        var record = me.getItemGrid().getSelectedItem();
        var view = Ext.widget('contract_item_form').show();
        var btn_save = view.down('button[action=save]', false);
        var btn_updt = view.down('button[action=update]', false);
        btn_save.hide();
        btn_updt.show();
        view.down('form').loadRecord(record);
    },

    divideSending: function() {
        var me = this;
        load_uniq_controller(me, 'contract.DivideSendingForm');
        var form = Ext.widget('divide_sending_form').show();
        //限制分批发货的最大数量为已经选择的项目中的数量-1
        var selection = Ext.ComponentQuery.query('contract_item_grid')[0].getSelectedItems()[0];
        var quantity = selection.get('quantity');
        form.down("numberfield").maxValue = quantity;
    },

    /**
     * 每次打开的时候重置菜单下的几个框
     * @param panel
     * @param eOpts
     */
    resetAllSubMenus: function(panel, eOpts) {
        panel.down("menuitem[action=quantity] numberfield").reset();
        panel.down("menuitem[action=send_status] combo").reset();
        panel.down("menuitem[action=check_and_accept_status] combo").reset();
        panel.down("menuitem[action=divide_sending] numberfield").reset();
        //限制分批发货的最大数量为已经选择的项目中数量的最小值-1
        //比如选了5 5 10，分批就只能分出4个来，变成1 1 6 4 4 4
        var selections = Ext.ComponentQuery.query('contract_item_grid')[0].getSelectedItems();
        var select_quantities = Ext.Array.pluck(Ext.Array.pluck(selections, "data"), "quantity");
        var max_quantity = Ext.Array.min(select_quantities) - 1;
        panel.down("menuitem[action=divide_sending] numberfield").maxValue = max_quantity;
    },

    /**
     * 批量修改数量的校验及提交
     * @param btn
     */
    batchEditQuantity: function(btn) {
        var me = this;
        me.unifiedBatchEdit(btn, 'numberfield', '/aaa/bbb');
    },

    /**
     * 批量修改发货状态的校验及提交
     * @param btn
     */
    batchEditSendStatus: function(btn) {
        var me = this;
        me.unifiedBatchEdit(btn, 'combo', '/aaa/ccc');
    },

    /**
     * 批量修改验收状态的校验及提交
     * @param btn
     */
    batchEditCheckAndAcceptStatus: function(btn) {
        var me = this;
        me.unifiedBatchEdit(btn, 'combo', '/aaa/ddd');
    },

    /**
     * 批量修改分批发货的校验及提交
     * @param btn
     */
    batchEditDivideSending: function(btn) {
        var me = this;
        me.unifiedBatchEdit(btn, 'numberfield', '/aaa/zzz');
    },

    /**
     * 批量修改质保条款的校验及提交
     * @param btn
     */
    batchEditTerm: function(btn) {
        var me = this;
        Ext.create('Ext.window.Window', {
            title: '批量修改质保条款',
            width: 450,
            height: 95,
            bodyPadding: 4,
            modal: true,

            items: [
                {
                    xtype: 'form',
                    bodyPadding: 4,
                    layout: 'anchor',
                    fieldDefaults: EIM_field_defaults,
                    items: [
                        {
                            xtype: 'container',//此container其实不用要，但为了和别的提交共用程序
                            layout: 'hbox',
                            items:[
                                {
                                    fieldLabel: '条款',
                                    xtype: 'combo',
                                    store: 'Terms',
                                    mode: 'remote',
                                    vtype: 'term',
                                    valueField: 'id',
                                    displayField: 'name',
                                    emptyText: '请输入并选择质保条款，格式见下面↓',
                                    triggerAction: 'query',
                                    minChars: 1,
                                    hideTrigger: true,
                                    width: 400,
//                                    anchor: '100%',
                                    allowBlank: false
                                },
                                {
                                    xtype: 'button',
                                    text: '确定',
                                    handler: function(btn) {
                                        me.unifiedBatchEdit(btn, 'combo', '/aaa/eee');
                                    }
                                }
                            ]
                        },
                        {
                            xtype: 'displayfield',
                            fieldLabel: '',
                            value: '格式：从(出厂|发货|到港|到货|客户验收|客户开始使用)起##个(月|小时)'
                        }
                    ]
                }
            ]
        }).show();
    },
    /**
     * 除日期选择器外的几个组件统一的批量提交行为
     * @param btn 当前button，不管
     * @param xtype button之前的控件的xtype，用来取要提交的值
     * @param url 要提交的路径
     */
    unifiedBatchEdit: function(btn, xtype, url) {
        var menu = btn.up('menu');
        var win = btn.up('window');
        var field = btn.up('container').down(xtype, false);
        var selections = Ext.ComponentQuery.query('contract_item_grid')[0].getSelectedItems();
        var select_ids = Ext.Array.pluck(Ext.Array.pluck(selections, "data"), "id");
//        console.log(field);
        if(field.isValid()) {
            Ext.Ajax.request({
                url: url,
                params: {
                    value: field.getValue(),
                    select_ids: select_ids.join("|")
                },
                success:function(response){
                    Ext.example.msg("OK", "修改成功！");
                },
                failure:function(){
                    Ext.Msg.alert('错误','你的网咋了？貌似不通的说……等一下再选吧！');
                }
            });
            if(menu) menu.up('menu').hide();
            if(win) win.close();
        }
    },

    batchEditExpectedLeaveFactory: function(picker, date, eOpts) {
        this.unifiedBatchDateEdit(date, '/date/aaa');
    },

    batchEditAppointedLeaveFactory: function(picker, date, eOpts) {
        this.unifiedBatchDateEdit(date, '/date/bbb');
    },

    batchEditActuallyLeaveFactory: function(picker, date, eOpts) {
        this.unifiedBatchDateEdit(date, '/date/ccc');
    },

    batchEditLeaveEtsc: function(picker, date, eOpts) {
        this.unifiedBatchDateEdit(date, '/date/ddd');
    },

    batchEditReachCustomer: function(picker, date, eOpts) {
        this.unifiedBatchDateEdit(date, '/date/eee');
    },

    batchEditCheckAndAccept: function(picker, date, eOpts) {
        this.unifiedBatchDateEdit(date, '/date/fff');
    },

    /**
     * 日期选择器统一的批量提交行为
     * @param date 选择的日期
     * @param url 要提交的路径
     */
    unifiedBatchDateEdit: function(date, url) {
        var selections = Ext.ComponentQuery.query('contract_item_grid')[0].getSelectedItems();
        var select_ids = Ext.Array.pluck(Ext.Array.pluck(selections, "data"), "id");
        Ext.Ajax.request({
            url: url,
            params: {
                date: Ext.Date.format(date, 'Y-m-d'),
                select_ids: select_ids.join("|")
            },
            success:function(response){
                Ext.example.msg("OK", "修改成功！");
            },
            failure:function(){
                Ext.Msg.alert('错误','你的网咋了？貌似不通的说……等一下再选吧！');
            }
        });
    },

    /**
     * 应收款的表单
     */
    addReceivable: function() {
        var me = this;
        load_uniq_controller(me, 'contract.ReceivableForm');
        var view = Ext.widget('receivable_form').show();
        var btn_save = view.down('button[action=save]', false);
        var btn_updt = view.down('button[action=update]', false);
        btn_save.show();
        btn_updt.hide();
    },
    editReceivable: function() {
        var me = this;
        load_uniq_controller(me, 'contract.ReceivableForm');
        var record = me.getReceivableGrid().getSelectedItem();
        var view = Ext.widget('receivable_form').show();
        var btn_save = view.down('button[action=save]', false);
        var btn_updt = view.down('button[action=update]', false);
        btn_save.hide();
        btn_updt.show();
        view.down('form').loadRecord(record);
    },
    receivableSelectionChange: function(selectionModel, selected, eOpts) {
        var grid = this.getReceivableGrid();
        var edit_btn = grid.down("[action=editReceivable]");

        //只选中一个时“修改”可用
        edit_btn.setDisabled(selected.length != 1);
    },

    /**
     * 实收款的表单
     */
    addCollection: function() {
        var me = this;
        load_uniq_controller(me, 'contract.CollectionForm');
        var view = Ext.widget('collection_form').show();
        var btn_save = view.down('button[action=save]', false);
        var btn_updt = view.down('button[action=update]', false);
        btn_save.show();
        btn_updt.hide();
    },
    editCollection: function() {
        var me = this;
        load_uniq_controller(me, 'contract.CollectionForm');
        var record = me.getCollectionGrid().getSelectedItem();
        var view = Ext.widget('collection_form').show();
        var btn_save = view.down('button[action=save]', false);
        var btn_updt = view.down('button[action=update]', false);
        btn_save.hide();
        btn_updt.show();
        view.down('form').loadRecord(record);
    },
    collectionSelectionChange: function(selectionModel, selected, eOpts) {
        var grid = this.getCollectionGrid();
        var edit_btn = grid.down("[action=editCollection]");

        //只选中一个时“修改”可用
        edit_btn.setDisabled(selected.length != 1);
    }
});