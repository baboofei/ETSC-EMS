Ext.define('EIM.model.ExpressCustomer', {
    extend: 'Ext.data.Model',
    fields: [{
        name: 'id',
        type: 'int'
    }, {
        name: 'name',
        type: 'string'
    }, {
        name: 'customer_unit_name',
        type: 'string'
    }, {
        name: 'phone',
        type: 'string'
    }, {
        name: 'mobile',
        type: 'string'
    }, {
        name: 'addr',
        type: 'string'
    }, {
        name: 'application_ids',
        type: 'string'
    }, {
        name: 'comment',
        type: 'string'
    }]
});