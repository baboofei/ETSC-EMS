Ext.define('EIM.model.Quote', {
    extend:'Ext.data.Model',
    fields:[
        {
            name:'id',
            type:'int'
        },
        {
            name:'quote_id',
            type:'int'
        },
        {
            name: 'customer_unit_id',
            type: 'int'
        },
        {
            name: 'customer_unit_name',
            type: 'string'
        },
        {
            name: 'customer_id',
            type: 'int'
        },
        {
            name: 'customer_name',
            type: 'string'
        },
        {
            name: 'salelog_id',
            type: 'int'
        },
        {
            name: 'salecase_id',
            type: 'int'
        },
        {
            name: 'salecase_number',
            type: 'string'
        },
        {
            name:'quote_number',
            type:'string'
        },
        {
            name:'summary',
            type:'string'
        },
        {
            name:'currency_id',
            type:'int'
        },
        {
            name: 'currency_name',
            type: 'string'
        },
        {
            name: 'fif_currency_id',
            type: 'int'
        },
        {
            name: 'fif_currency_name',
            type: 'string'
        },
        {
            name: 'total_discount',//总折扣
            type: 'float'
        },
        {
            name: 'fif',//运保费
            type: 'float'
        },
        {
            name: 'vat',
            type: 'decimal'
        },
        {
            name: 'other_cost',//这个虽然那天肖姐姐暴怒说确定一定以及肯定不要这一项，但我看还是留着吧，毕竟以前有的
            type: 'float'
        },
        {
            name: 'total',//合计
            type: 'float'
        },
        {
            name: 'sale_user_id',
            type: 'int'
        },
        {
            name: 'sale_user_name',
            type: 'string'
        },
        {
            name: 'business_user_id',
            type: 'int'
        },
        {
            name: 'business_user_name',
            type: 'string'
        },
        {
            name: 'work_task_id',//任务。之前一直说做但没做的模块，跟消息可能有重叠的地方
            type: 'int'
        },
        {
            name: 'work_task_number',
            type: 'string'
        },
        {
            name: 'language',
            type: 'int'
        },
        {
            name: 'request',//报价要求
            type: 'string'
        },
        {
            name: 'quote_format',
            type: 'int'
        },
        {
            name: 'quote_format_name',
            type: 'int'
        },
        {
            name: 'our_company_id',
            type: 'int'
        },
        {
            name: 'our_company_name',
            type: 'string'
        },
        {
            name: 'quote_type',
            type: 'int'
        },
        {
            name: 'term',//JSON
            type: 'text'
        },
        {
            name: 'pdf',//JSON
            type: 'text'
        },
        {
            name: 'remark',
            type: 'text'
        },
        {
            name: 'status',//本来是想用来区分进展到哪一步了，但现在大家都可以看，所以用处好像不大了
            type: 'int'
        },
        {
            name: 'created_at',
            type: 'date'
        },
        {
            name: 'updated_at',
            type: 'date'
        }
    ]
});