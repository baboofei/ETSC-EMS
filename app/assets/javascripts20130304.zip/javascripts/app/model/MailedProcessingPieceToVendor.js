Ext.define('EIM.model.MailedProcessingPieceToVendor', {
    extend: 'Ext.data.Model',
    fields: [{
        name: 'id',
        type: 'int'
    }, {
    	name: 'model',
    	type: 'string'
    }, {
        name: 'quantity',
        type: 'int'
    }, {
        name: 'express_id',
        type: 'int'
    }, {
        name: 'tracking_number',
        type: 'string'
    }, {
    	name: 'remind_on',
    	type: 'date'
    }]
});