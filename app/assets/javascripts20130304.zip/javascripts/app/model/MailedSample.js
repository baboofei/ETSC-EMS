Ext.define('EIM.model.MailedSample', {
    extend: 'Ext.data.Model',
    fields: [{
        name: 'id',
        type: 'int'
    }, {
        name: 'express_id',
        type: 'int'
    }, {
        name: 'model',
        type: 'string'
    }, {
    	name: 'quantity',
    	type: 'int'
    }, {
    	name: 'remind_on',
    	type: 'date'
    }, {
    	name: 'tracking_number',
    	type: 'string'
//    }, {
//        name: 'comment',
//        type: 'string'
    }]
});
