Ext.define('EIM.model.dict.City', {
    extend : 'Ext.data.Model',
    fields: [{
        name: 'id',
        type: 'int'
    }, {
        name: 'name',
        type: 'string'
    }
//    , {
//        name: 'exact_name',
//        type: 'string'
//    }
    ]
});
