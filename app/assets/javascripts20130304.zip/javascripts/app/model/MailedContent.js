Ext.define('EIM.model.MailedContent', {
    extend: 'Ext.data.Model',
    fields: [{
        name: 'id',
        type: 'int'
    }, {
        name: 'express_id',
        type: 'int'
    }, {
        name: 'tracking_number',
        type: 'string'
    }, {
        name: 'detail',
        type: 'string'
    }]
});