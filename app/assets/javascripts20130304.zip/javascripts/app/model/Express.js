Ext.define('EIM.model.Express', {
    extend : 'Ext.data.Model',
    fields: [{
        name: 'id',
        type: 'int'
    },{
        name: 'name',
        type: 'string'
    },{
        name: 'phoneNumber',
        type: 'string'
    }]
});
