/**
 * 这个是寄产品的store，要取的JSON值见model\MailedProduct
 * 另外，那边的vendor_unit_id和product_id要写成type: 'string'，因为你在后台就给定成字符了
 */
Ext.define('EIM.store.MailedProducts', {
    extend: 'Ext.data.Store',
    model: 'EIM.model.MailedProduct',

    autoLoad: false,

    proxy: {
        type: 'ajax',
        url: '/users/fake_for_salecase',
        format: 'json',
        method: 'GET',
        reader: {
            root: 'salecases',
            successProperty: 'success',
            totalProperty:'totalRecords'
        },
        writer: {
            getRecordData: function(record){
                return {user: record.data}
            }
        }
    }
});