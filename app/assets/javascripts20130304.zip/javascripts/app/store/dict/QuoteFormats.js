Ext.define('EIM.store.dict.QuoteFormats', {
    extend:'Ext.data.Store',
    model:'EIM.model.dict.QuoteFormat',

    autoLoad:false,

    proxy:{
        url:'/users/fake_for_quote_format',
        type:'ajax',
//        format: 'json',
        method:'GET',
        reader:{
            type:'json',
            root:'quote_formats',
            successProperty:'success',
            totalProperty:'totalRecords'
        }
    }
});