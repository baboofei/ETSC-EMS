Ext.define('EIM.store.dict.Applications', {
    extend:'Ext.data.Store',
    model:'EIM.model.dict.Application',

    autoLoad:false,

    proxy:{
        url:'/users/fake_for_application',
        type:'ajax',
//        format: 'json',
        method:'GET',
        reader:{
            type:'json',
            root:'applications',
            successProperty:'success',
            totalProperty:'totalRecords'
        }
    }
});