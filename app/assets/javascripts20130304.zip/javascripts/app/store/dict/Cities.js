Ext.define('EIM.store.dict.Cities', {
    extend:'Ext.data.Store',
    model:'EIM.model.dict.City',

    autoLoad:false,

    proxy:{
        url:'/users/fake_for_city',
        type:'ajax',
//        format: 'json',
        method:'GET',
        reader:{
            type:'json',
            root:'cities',
            successProperty:'success',
            totalProperty:'totalRecords'
        }
    }
});