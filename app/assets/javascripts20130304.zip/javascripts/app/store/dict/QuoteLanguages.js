Ext.define('EIM.store.dict.QuoteLanguages', {
    extend:'Ext.data.Store',
    model:'EIM.model.dict.QuoteLanguage',

    autoLoad:false,

    proxy:{
        url:'/users/fake_for_quote_language',
        type:'ajax',
//        format: 'json',
        method:'GET',
        reader:{
            type:'json',
            root:'quote_languages',
            successProperty:'success',
            totalProperty:'totalRecords'
        }
    }
});