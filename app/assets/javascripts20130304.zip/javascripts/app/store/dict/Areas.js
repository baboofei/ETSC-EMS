Ext.define('EIM.store.dict.Areas', {
    extend:'Ext.data.Store',
    model:'EIM.model.dict.Area',

    autoLoad:false,

    proxy:{
        url:'/users/fake_for_city',
        type:'ajax',
//        format: 'json',
        method:'GET',
        reader:{
            type:'json',
            root:'cities',
            successProperty:'success',
            totalProperty:'totalRecords'
        }
    }
});