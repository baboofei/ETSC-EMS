Ext.define('EIM.store.dict.QuoteTypes', {
    extend:'Ext.data.Store',
    model:'EIM.model.dict.QuoteType',

    autoLoad:false,

    proxy:{
        url:'/users/fake_for_quote_type',
        type:'ajax',
//        format: 'json',
        method:'GET',
        reader:{
            type:'json',
            root:'quote_types',
            successProperty:'success',
            totalProperty:'totalRecords'
        }
    }
});