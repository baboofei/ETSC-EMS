/**
 * 字典项拼的大store
 */
Ext.define('EIM.store.AllDicts', {
    extend:'Ext.data.Store',
    model:'EIM.model.AllDict',

    autoLoad: true,

    proxy:{
        url:'/users/fake_for_all_dict',
        type:'ajax',
        format:'json',
        method:'GET',
        reader:{
            root:'all_dicts',
            successProperty:'success',
            totalProperty:'totalRecords'
        },
        writer:{
            getRecordData:function (record) {
                return {user:record.data}
            }
        }
    },
    listeners: {
        'load' :  function(store,records,options) {
//            console.log(records[0].data);
            Ext.Array.each(records, function(item, index, allItems) {
                Ext.ComponentQuery.query('functree')[0].allLL.push(item.data);
            });
        }
    }
});