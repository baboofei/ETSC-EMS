/**
 * 进出口公司联系人store
 */
Ext.define('EIM.store.BusinessContacts', {
    extend:'Ext.data.Store',
    model:'EIM.model.BusinessContact',

    autoLoad:false,

    proxy:{
        url:'/users/fake_for_business_contact', //TODO 要改的……
        type:'ajax',
        format:'json',
        method:'GET',
        reader:{
            root:'business_contacts',
            successProperty:'success',
            totalProperty:'totalRecords'
        },
        writer:{
            getRecordData:function (record) {
                return {user:record.data}
            }
        }
    }
});