/**
 * 卖方公司store
 */
Ext.define('EIM.store.ComboOurCompanies', {
    extend:'Ext.data.Store',
    model:'EIM.model.ComboOurCompany',

    autoLoad:false,

    proxy:{
        url:'/users/fake_for_combo_our_company',
        type:'ajax',
        format:'json',
        method:'GET',
        reader:{
            root:'our_companies',
            successProperty:'success',
            totalProperty:'totalRecords'
        },
        writer:{
            getRecordData:function (record) {
                return {user:record.data}
            }
        }
    }
});