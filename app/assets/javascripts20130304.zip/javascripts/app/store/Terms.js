/**
 * 这个是质保条款的store，要取的JSON值见model\Term
 */
Ext.define('EIM.store.Terms', {
    extend:'Ext.data.Store',
    model:'EIM.model.Term',

    autoLoad:false,

    proxy:{
        type:'ajax',
        url:'/users/fake_for_term', //TODO 要改
        format:'json',
        method:'GET',
        reader:{
            root:'terms',
            successProperty:'success',
            totalProperty:'totalRecords'
        },
        writer:{
            getRecordData:function (record) {
                return {user:record.data}
            }
        }
    }
});