/**
 * 这个是付款方式的store，要取的JSON值见model\PayMode
 */
Ext.define('EIM.store.PayModes', {
    extend:'Ext.data.Store',
    model:'EIM.model.PayMode',

    autoLoad:false,

    proxy:{
        type:'ajax',
        url:'/users/fake_for_pay_mode', //TODO 要改
        format:'json',
        method:'GET',
        reader:{
            root:'pay_modes',
            successProperty:'success',
            totalProperty:'totalRecords'
        },
        writer:{
            getRecordData:function (record) {
                return {user:record.data}
            }
        }
    }
});