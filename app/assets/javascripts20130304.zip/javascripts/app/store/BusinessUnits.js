/**
 * 进出口公司store
 */
Ext.define('EIM.store.BusinessUnits', {
    extend:'Ext.data.Store',
    model:'EIM.model.BusinessUnit',

    autoLoad:false,

    proxy:{
        url:'/users/fake_for_business_unit', //TODO 要改的……
        type:'ajax',
        format:'json',
        method:'GET',
        reader:{
            root:'business_units',
            successProperty:'success',
            totalProperty:'totalRecords'
        },
        writer:{
            getRecordData:function (record) {
                return {user:record.data}
            }
        }
    }
});