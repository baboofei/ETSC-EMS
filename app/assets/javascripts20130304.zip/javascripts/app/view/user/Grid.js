Ext.define('EIM.view.user.Grid', {
    extend: 'Ext.grid.Panel',
    alias : 'widget.user_grid',

    title : 'All Users',
    store: 'Users',
    autoRender: true,

    initComponent: function() {
        this.columns = [
            { header: '姓名',  dataIndex: 'name',  flex: 1 },
            { header: '英文名',  dataIndex: 'user',  flex: 1 },
            { header: 'Email', dataIndex: 'email', flex: 1 }
        ];

        this.addUserButton = new Ext.Button({
            text: 'Add User',
            action: 'addUser'
        });

        this.editUserButton = new Ext.Button({
            text: 'Edit user',
            action: 'editUser',
            disabled: true
        });

        this.deleteUserButton = new Ext.Button({
            text: 'Delete User',
            action: 'deleteUser',
            disabled: true
        });

        this.printButton = new Ext.Button({
            text: '打印测试',
            action: 'print'
        });

        this.bbar = [this.addUserButton, this.editUserButton, this.deleteUserButton, this.printButton];

        this.callParent(arguments);
    },

    getSelectedUser: function() {
        return this.getSelectionModel().getSelection()[0];
    },

    enableRecordButtons: function() {
        this.editUserButton.enable();
        this.deleteUserButton.enable();
    },

    disableRecordButtons: function() {
        this.editUserButton.disable();
        this.deleteUserButton.disable();
    }
});
