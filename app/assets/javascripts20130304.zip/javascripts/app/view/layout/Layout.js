Ext.define('EIM.view.layout.Layout', {
    extend:'Ext.container.Viewport',
    alias:'widget.eim_layout',
//    autoRender: true,
//    renderTo: Ext.getBody(),

    layout:'border',
    disabled:true,
    items:[
        {
            title:'上',
            region:'north',
            layout:'fit',
            height:50,
            xtype:'panel'
        },
        {
            region:'west',
            margins:'2 0 2 2',
            collapsible:true,
            split:true,
            xtype:'functree'
        },
        {
            region:'center',
            id:'center',
            xtype:'tabpanel',
            margins:'2 2 2 0',
//        autoDestroy: false,
//        layout: 'fit',
            items:[
                {
                    title:'Foo',
                    id:'Foo-tab',
                    xtype:'user_grid'
                },
                {
                    title:'标题二',
                    id:'Bar-tab',
                    tabConfig:{
                        title:'啥东东',
                        tooltip:'提示'
                    },
                    xtype:'functree'
                }
            ]
        }
    ],

    initComponent:function () {
        this.callParent(arguments);
    }
});