Ext.define('EIM.view.express_sheet.SearchGrid', {
    extend: 'Ext.grid.Panel',
    alias: 'widget.express_sheet_search_grid',

    requires:'Ext.ux.grid.FiltersFeature',

    store: 'ExpressCustomers',
    iconCls: 'ttl_grid',
    multiSelect: true,
    stripeRows: true,

    initComponent: function() {
        var me = this;
        //“区域”的字典项，供表格中显示和表头筛选用
        var areaArray;
        var areaStore = Ext.getStore('dict.Areas');
        //        var applicationStore = Ext.data.StoreManager.lookup('dict.Applications');
        areaStore.load(function () {
            //这一部分是给renderer用的
            areaArray = Ext.pluck(areaStore.data.items, 'data');
            //这一部分是给filter用的
            var options = Ext.Array.map(areaArray, function (record) {
                return [record["id"], record["name"]];
            });
            var target_col = me.getView().getHeaderCt().child('[dataIndex=area_name]');
            target_col.initialConfig.filter.options = options;
        });

        //“涉及应用”的字典项，供表格中显示和表头筛选用
        var applicationArray;
        var applicationStore = Ext.getStore('dict.Applications');
        //        var applicationStore = Ext.data.StoreManager.lookup('dict.Applications');
        applicationStore.load(function () {
            //这一部分是给renderer用的
            applicationArray = Ext.pluck(applicationStore.data.items, 'data');
            //这一部分是给filter用的
            var options = Ext.Array.map(applicationArray, function (record) {
                return [record["id"], record["name"]];
            });
            var target_col = me.getView().getHeaderCt().child('[dataIndex=application_ids]');
            target_col.initialConfig.filter.options = options;
        });

        this.columns = [
            {
                header:'姓名',
                dataIndex:'name',
                width:75,
                sortable:true,
                filter:{
                    type:'string'
                }
            },
            {
                header:'客户单位',
                dataIndex:'customer_unit_name',
                width:150,
                sortable:true,
                filter:{
                    type:'string'
                }
            },
            {
                header: '区域',
                dataIndex: 'area_name',
                width: 50,
                sortable: true,
                filter: {
                    type:'list',
                    phpMode:true,
                    options:[]
                }
            },
            {
                header: '城市',
                dataIndex: 'city_name',
                width: 50,
                sortable: true,
                filter: {
                    type:'string'
                }
            },
            {
                header: '单位性质',
                dataIndex: 'customer_unit_sort',
                width: 75,
                sortable: true,
                filter: {
                    type: 'list',
                    phpMode: true,
                    options: []
                }
            },
            {
                header:'涉及应用',
                dataIndex:'application_ids',
                width:100,
                sortable:true,
                filter:{
                    type:'list',
                    phpMode:true,
                    options:[]
                },
                renderer:function (value) {
                    var display = [];
                    var idArray = value.split("|");
                    for (var i = 0; i < idArray.length; i++) {
                        for (var j = 0; j < applicationArray.length; j++) {
                            if (applicationArray[j]["id"] === Number(idArray[i])) {
                                display.push(applicationArray[j]["name"]);
                            }
                        }
                    }
                    return display.join("、");
                }
            },
            {
                header:'备注',
                dataIndex:'comment',
                width:50,
                sortable:true,
                filter:{
                    type:'list',
                    phpMode:true,
                    options:[]
                },
                flex: 1
            }
        ];

        this.pagingToolbar = Ext.create('Ext.PagingToolbar', {
            store:this.store,
            displayInfo:true,
            border:0,
            minWidth:380
        });

        this.features = [
            {
                ftype:'filters',
                encode:true
            }
        ];

        this.bbar = this.displayPaging ? [this.pagingToolbar] : this.bbar;

        this.callParent(arguments);
    }
});