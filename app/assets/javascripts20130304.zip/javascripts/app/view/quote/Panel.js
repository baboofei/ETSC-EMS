Ext.define('EIM.view.quote.Panel', {
    extend:'Ext.panel.Panel',
    alias:'widget.quote_panel',

    layout:'border',
    items:[
        {
            xtype:'quote_grid',
            height:300,
            minHeight:100,
            maxHeight:400,
            region:'north',
            padding:"4 4 0 4",
            collapsible: true,
//        border: 0,
            split:true
        },
        {
//            xtype:'panel',
            xtype:'quote_detail',
            region:'center',
            padding:"0 4 4 4",
//        title: 'bb',
            split:true
        },
        {
            /**
             * 用来存所有币种的汇率的缓存
             * “报价”标签打开的时候重新加载一次它的内容
             * “修改汇率”里的改变提交后，后台存新汇率，同时它变
             * 它onchange时，改变“报价项”和“报价块”里的汇率hidden
             * 它的格式："[{'currency': 'USD', 'exchange_rate': 622.82}, {'currency': 'EUR', 'exchange_rate': 808.17}, ...]"
             */
            xtype: 'hidden',
            region: 'east',
            name: 'exchange_rate_hash',
            value: "[{'currency': 'USD', 'exchange_rate': 622.82}, {'currency': 'EUR', 'exchange_rate': 808.17}, {'currency': 'JPY', 'exchange_rate': 7.58}]"
        }
    ],

    buttons:[
        {
            text:'保存本报价',
            action:'save',
            disabled: true
        },
        {
            text:'保存为新报价',
            action:'save_as',
            disabled: true
        },
        {
            text: '保存并生成PDF',
            action: 'generate_pdf',
            disabled: true,
            hidden: true
        }
    ],

    initComponent:function () {
        this.callParent(arguments);
    }
});