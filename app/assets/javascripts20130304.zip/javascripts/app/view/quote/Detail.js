Ext.define('EIM.view.quote.Detail', {
    extend: 'Ext.tab.Panel',
    alias: 'widget.quote_detail',

    items: [
        {
            xtype: 'quote_info'
        },
        {
            xtype: 'quote_item_panel'
        },
        {
            xtype: 'quote_term'
        }
    ],

    initComponent: function() {
        this.callParent(arguments);
    }
});