Ext.define('EIM.view.quote.Grid', {
    extend:'Ext.grid.Panel',
    alias:'widget.quote_grid',

    requires:'Ext.ux.grid.FiltersFeature',

    title:'报价列表',
    store:'Quotes',
    iconCls:'ttl_grid',

    initComponent:function () {
        var ownerStore = Ext.data.StoreManager.lookup('Users');
//        var me = this;
//        //“合同类别”的字典项，供表格中显示和表头筛选用
//        var quoteTypeArray;
//        var quoteTypeStore = Ext.getStore('dict.QuoteTypes');
////        var quoteTypeStore = Ext.data.StoreManager.lookup('dict.QuoteTypes');
//        quoteTypeStore.load(function () {
//            //这一部分是给renderer用的
//            quoteTypeArray = Ext.pluck(quoteTypeStore.data.items, 'data');
//            //这一部分是给filter用的
//            var options = Ext.Array.map(quoteTypeArray, function (record) {
//                return [record["id"], record["name"]];
//            });
//            var target_col = me.getView().getHeaderCt().child('[dataIndex=quote_type_id]');
//            target_col.initialConfig.filter.options = options;
//        });

        this.columns = [
            {
                header:'个案编号',
                dataIndex:'salecase_number',
                width:75,
                sortable:true,
                filter:{
                    type:'string'
                }
            },
            {
                header:'报价编号',
                dataIndex:'quote_number',
                width:75,
                sortable:true,
                filter:{
                    type:'string'
                }
            },
            {
                header: '商务',
                dataIndex: 'business_user_name',
                width: 50,
                sortable: true,
                filter: {
                    type:'list',
                    phpMode:true,
                    options:[]
                }
            },
            {
                header: '报价日期',
                dataIndex: 'created_at',
                width: 75,
                sortable: true,
                filter: {
                    type: 'date'
                }
            },
            {
                header: '报价摘要',
                dataIndex: 'summary',
                flex: 1,
                sortable: true,
                filter:{
                    type:'string'
                }
            },
            {
                header:'币种',
                dataIndex:'currency_name',
                width:50,
                sortable:true,
                filter:{
                    type:'list',
                    phpMode:true,
                    options:[]
                }
            },
            {
                header:'金额',
                dataIndex:'total',
                width:50,
                sortable:true,
                filter: {
                    type: 'number'
                }
            },
            {
                header: '负责工程师',
                dataIndex: 'sale_user_name',
                width: 50,
                sortable: true,
                filter: {
                    type:'list',
                    phpMode:true,
                    options:[]
                }
            },
            {
                header: '客户单位',
                dataIndex: 'customer_unit_name',
                width: 150,
                sortable: true,
                filter: {
                    type: 'string'
                }
            },
            {
                header: '客户',
                dataIndex: 'customer_name',
                width: 50,
                sortable: true,
                filter: {
                    type: 'string'
                }
            },
            {
            	header: '下载',
            	dataIndex: 'status',
            	width: 30,
            	sortable: true,
            	renderer: function(value, metaData, record) {
            		var text;
                    if(value != 0) {
                        //如果不是0，则显示一个图标
                    	text = "<a href='#'>下载</a>";
                    }
                    return text;
                }
            }
        ];

        this.addQuoteButton = Ext.create('Ext.Button', {
            text:'新增报价',
            iconCls:'btn_add',
            action:'addQuote'
        });
        this.pagingToolbar = Ext.create('Ext.PagingToolbar', {
            store:this.store,
            displayInfo:true,
            border:0,
            minWidth:380
        });

        this.features = [
            {
                ftype:'filters',
                encode:true
            }
        ];

        this.bbar = [this.addQuoteButton, '-', this.pagingToolbar];

        this.callParent(arguments);
    },

    getSelectedItem:function () {
        return this.getSelectionModel().getSelection()[0];
    }
});