Ext.define('EIM.view.quote.Info', {
    extend: 'Ext.form.Panel',
    alias: 'widget.quote_info',

    title: '报价信息',
    //    iconCls: 'ttl_config',

    bodyPadding: 4,
    autoScroll: true,
    layout: 'anchor',
    fieldDefaults: EIM_field_defaults,

    items: [
        {
            xtype: 'textfield',
            name: 'quote_id'
        },
        {
            xtype: 'container',
            layout: 'hbox',
            defaults: {
                flex: 1
            },
            items: [
                {
                    xtype: 'expandable_customer_unit_combo',
                    allowBlank: false
                },
                {
                    xtype: 'expandable_customer_combo',
                    allowBlank: false
                },
                {
                    xtype: 'textfield',
                    fieldLabel: '报价编号',
                    name: 'quote_number',
                    disabled: true
                }
            ]
        },
        {
            xtype: 'container',
            layout: 'hbox',
            defaults: {
                flex: 1
            },
            padding: '4 0 0 0',
            items: [
                {
                    xtype: 'combo',
                    fieldLabel: '卖方公司',
                    name: 'our_company_id',
                    allowBlank: false,
                    editable: false,
                    store: 'ComboOurCompanies',
                    valueField: 'id',
                    displayField: 'name'
                },
                {
                    xtype: 'combo',
                    fieldLabel: '工程师',
                    name: 'sale_user_id',
                    allowBlank: false,
                    editable: false,
                    store: 'ComboSales',
                    valueField: 'id',
                    displayField: 'name'
                },
                {
                    xtype: 'combo',
                    fieldLabel: '个案编号',
                    name: 'case_id',
                    allowBlank: false,
                    editable: false,
                    store: 'ComboSalecases',
                    valueField: 'id',
                    displayField: 'number'
                }
            ]
        },
        {
            xtype: 'container',
            layout: 'hbox',
            defaults: {
                flex: 1
            },
            padding: '4 0 0 0',
            items: [
                {
                    xtype: 'combo',
                    fieldLabel: '报价类型',
                    name: 'quote_type',
                    allowBlank: false,
                    editable: false,
                    store: Ext.create('Ext.data.Store', {
                        data: filter_all_dict('quote_type'),
                        model: 'EIM.model.AllDict',
                        proxy:  'memory'
                    }),
                    valueField: 'id',
                    displayField: 'name'
                },
                {
                    xtype: 'combo',
                    fieldLabel: '报价语言',
                    name: 'quote_language',
                    allowBlank: false,
                    editable: false,
                    store: Ext.create('Ext.data.Store', {
                        data: filter_all_dict('quote_language'),
                        model: 'EIM.model.AllDict',
                        proxy:  'memory'
                    }),
                    valueField: 'id',
                    displayField: 'name'
                },
                {
                    xtype: 'combo',
                    fieldLabel: '报价格式',
                    name: 'quote_format',
                    allowBlank: false,
                    editable: false,
                    store: Ext.create('Ext.data.Store', {
                        data: filter_all_dict('quote_format'),
                        model: 'EIM.model.AllDict',
                        proxy:  'memory'
                    }),
                    valueField: 'id',
                    displayField: 'name'
                }
            ]
        },
        {
            xtype: 'container',
            layout: 'hbox',
            defaults: {
                flex: 1
            },
            padding: '4 0',
            items: [
                {
                    xtype: 'textfield',
                    fieldLabel: '报价摘要',
                    name: 'summary',
                    flex: 2
                },
                {
                    xtype: 'datefield',
                    fieldLabel: '报价日期',
                    name: 'created_on',
                    allowBlank: false,
                    format: 'Y-m-d',
                    value: new Date()
                }
            ]
        },
        {
            xtype: 'textfield',
            fieldLabel: '报价要求',
            emptyText: '销售对报价条款上的一些要求',
            name: 'requirement'
        }
    ]
});