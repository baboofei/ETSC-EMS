Ext.define('EIM.view.salecase.Detail', {
    extend:'Ext.form.Panel',
    alias:'widget.salecase_detail',

    title:'销售个案详情',
    bodyPadding:4,
//    frame: true,
    autoScroll:true,
    layout:'border',

    items:[
        {
            xtype:'salelog_grid',
            region:'center'
        },
        {
            xtype:'panel',
            region:'west',
            width:450,
            split:true,
            layout:'border',
            border:0,
            padding:0,
            items:[
                {
                    xtype:'form',
                    title:'个案信息',
                    id:'salecase_info',
                    region:'north',
                    split:true,
                    autoScroll:true,
//                id: 'add_salecase_form',
//            padding: '3 3 1 3',
                    height:170,
                    bodyPadding:4,
//                border: 0,
                    layout:'form',
                    url:'', //这
                    fieldDefaults:EIM_field_defaults,
                    items:[
                        {
                            xtype:'numberfield',
                            name:'feasible',
                            allowBlank:false,
                            fieldLabel:'成案率(%)',
                            emptyText:'请估计此个案的成案率'
                        },
                        {
                            xtype:'combo',
                            name:'priority',
                            fieldLabel:'优先级',
                            store:[
                                [1, "普通"],
                                [2, "加急"]
                            ],
                            emptyText:'请选择优先级',
                            allowBlank:false,
                            mode:'local',
//                    value: 1,
                            editable:false,
                            triggerAction:'all'
                        },
                        {
                            xtype:'textfield',
                            name:'comment',
                            allowBlank:false,
                            fieldLabel:'个案描述',
                            emptyText:'请输入对此个案的描述'
                        },
                        {
                            xtype:'datefield',
                            name:'remind',
                            allowBlank:true,
                            format:'Y-m-d',
                            value:Ext.Date.add(new Date(), Ext.Date.DAY, 15),
                            fieldLabel:'提醒时间',
                            emptyText:'请选择需要提醒的时间'
                        }
                    ],
                    buttons:[
                        {
                            text:'确定',
                            action:'salecaseSubmit',
                            disabled: true
                        }
                    ]
                },
                {
                    xtype:'customer_mini_grid',
                    title:'联系人列表',
//            id: 'customer_grid',
                    region:'center'/*,
                 store: 'Users'*/
                }
            ]
        }
    ],

    initComponent:function () {
        this.callParent(arguments);
    }
});