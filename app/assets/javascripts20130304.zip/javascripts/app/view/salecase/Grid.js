Ext.define('EIM.view.salecase.Grid', {
    extend:'Ext.grid.Panel',
    alias:'widget.salecase_grid',

    requires:'Ext.ux.grid.FiltersFeature',

    title:'销售个案列表',
    store:'Salecases',
    iconCls:'ttl_grid',

    initComponent:function () {
        var ownerStore = Ext.data.StoreManager.lookup('Users');

        this.columns = [
            {
                header:'个案编号',
                dataIndex:'number',
                width:75,
                sortable:true,
                filter:{
                    type:'string'
                }
            },
            {
                header:'个案描述',
                dataIndex:'comment',
                flex:1,
                sortable:true
            },
            {
                header:'起始日期',
                dataIndex:'start_time',
                width:100,
                sortable:true,
                filter:{
                    type:'date'
                },
                renderer:Ext.util.Format.dateRenderer("Y-m-d")
            },
            {
                header:'结束日期',
                dataIndex:'end_time',
                width:100,
                sortable:true,
                filter:{
                    type:'date'
                },
                renderer:Ext.util.Format.dateRenderer("Y-m-d")
            },
            {
                header:'负责人',
                dataIndex:'user',
                width:50,
                sortable:true,
                filter:{
                    type:'list',
                    options:Ext.Array.map(ownerStore.getRange(), function (record) {
                        return [record.get("id"), record.get("name")];
                    })
                },
                renderer:function (value, metaData, record) {
                    if (record["raw"]["user"]) {
                        return record["raw"]["user"]["name"];
                    } else {
                        return "";
                    }
                }
            },
            {
                header:'客户联系人',
                dataIndex:'customers',
                width:200,
                sortable:false,
                renderer:function (value, metaData, record) {
                    if (record["raw"]["customers"]) {
                        var names = [];
                        Ext.each(record["raw"]["customers"], function (v) {
                            names.push(v["name"]);
                        });
                        return names.join("、");
                    } else {
                        return "";
                    }
                }
            },
            {
                header:'优先级',
                dataIndex:'priority',
                width:50,
                sortable:true,
                filter:{
                    type:'list',
                    options:[
                        [1, "普通"],
                        [2, "加急"]
                    ]
                },
                renderer:function (value) {
                    var array = [
                        [1, "普通"],
                        [2, "加急"]
                    ];
                    if (value) {
                        for (var i = 0; i < array.length; i++) {
                            if (array[i][0] == value) {
                                return array[i][1];
                            }
                        }
                    } else {
                        return "";
                    }
                }
            },
            {
                header:'成案率(%)',
                dataIndex:'feasible',
                width:100,
                sortable:true,
                filter:{
                    type:'numeric'
                }
            },
            {
                header:'提醒时间',
                dataIndex:'remind',
                width:100,
                sortable:true,
                filter:{
                    type:'date'
                },
                renderer:Ext.util.Format.dateRenderer("Y-m-d")
            }
        ];

        this.addSalecaseButton = Ext.create('Ext.Button', {
            text:'新增个案',
            iconCls:'btn_add',
            action:'addSalecase'
        });
        this.pagingToolbar = Ext.create('Ext.PagingToolbar', {
            store:this.store,
            displayInfo:true,
            border:0,
            minWidth:380
        });

        this.features = [
            {
                ftype:'filters',
                encode:true
            }
        ];

        this.bbar = [this.addSalecaseButton, '-', this.pagingToolbar];

        this.callParent(arguments);
    },

    getSelectedItem:function () {
        return this.getSelectionModel().getSelection()[0];
    }
});