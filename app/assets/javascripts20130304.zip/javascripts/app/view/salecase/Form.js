Ext.define('EIM.view.salecase.Form', {
    extend:'Ext.window.Window',
    alias:'widget.salecase_form',

    title:'新增个案',
    layout:'fit',
    width:300,
    height:240,
    modal:true,
//    autoShow: true,

    initComponent:function () {
        this.items = [
            {
                xtype:'form',
                bodyPadding:4,
                layout:'anchor',
                fieldDefaults:EIM_field_defaults,
                items:[
                    {
                        xtype:'hidden',
                        name:'id',
                        fieldLabel:'id'
                    },
                    {
                        xtype:'expandable_customer_unit_combo',
                        name:'customer_unit_id',
                        fieldLabel:'客户单位',
                        listeners:{
                        }
                    },
                    {
                        xtype:'expandable_customer_combo',
                        name:'customer_id',
                        padding:'5 0',
                        fieldLabel:'客户'
                    },
                    {
                        xtype:'textfield',
                        name:'comment',
                        fieldLabel:'个案描述',
                        emptyText:'请输入便于记忆的个案描述',
                        allowBlank:false
                    },
                    {
                        xtype:'combo',
                        name:'priority',
                        fieldLabel:'优先级',
                        store:[
                            [1, "普通"],
                            [2, "加急"]
                        ],
                        emptyText:'请选择优先级',
                        allowBlank:false,
                        mode:'local',
                        value:1,
                        editable:false,
                        triggerAction:'all'
                    },
                    {
                        xtype:'numberfield',
                        name:'feasible',
                        allowBlank:false,
                        fieldLabel:'成案率(%)',
                        emptyText:'请估计此个案的成案率',
                        minValue:0,
                        maxValue:100
                    },
                    {
                        xtype:'datefield',
                        name:'remind',
                        allowBlank:true,
                        format:'Y-m-d',
                        value:Ext.Date.add(new Date(), Ext.Date.DAY, 15),
                        fieldLabel:'提醒时间',
                        emptyText:'请选择需要提醒的时间'
                    }
                ]
            }
        ];

        this.buttons = [
            {
                text:'保存',
//            formBind: true,
//            disabled: true,
                action:'save'
            },
            {
                text:'取消',
                scope:this,
                handler:this.close
            }
        ];

        this.callParent(arguments);
    }
});