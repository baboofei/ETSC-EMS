Ext.define('EIM.view.customer.Grid', {
    extend:'Ext.grid.Panel',
    alias:'widget.customer_grid',

    requires:'Ext.ux.grid.FiltersFeature',

    title:'客户列表',
    store:'Customers',
    iconCls:'ttl_grid',

    initComponent:function () {
        var me = this;
        //“结识方式”的字典项，供表格中显示和表头筛选用
        var leadArray;
        var leadStore = Ext.data.StoreManager.lookup('dict.Leads');
        leadStore.load(function () {
            //这一部分是给renderer用的
            leadArray = Ext.pluck(leadStore.data.items, 'data');
            //这一部分是给filter用的
            var options = Ext.Array.map(leadArray, function (record) {
                return [record["id"], record["name"]];
            });
            var target_col = me.getView().getHeaderCt().child('[dataIndex=lead_id]');
            target_col.initialConfig.filter.options = options;
        });
        //“涉及应用”的字典项，供表格中显示和表头筛选用
        var applicationArray;
        var applicationStore = Ext.getStore('dict.Applications');
//        var applicationStore = Ext.data.StoreManager.lookup('dict.Applications');
        applicationStore.load(function () {
            //这一部分是给renderer用的
            applicationArray = Ext.pluck(applicationStore.data.items, 'data');
            //这一部分是给filter用的
            var options = Ext.Array.map(applicationArray, function (record) {
                return [record["id"], record["name"]];
            });
            var target_col = me.getView().getHeaderCt().child('[dataIndex=application_ids]');
            target_col.initialConfig.filter.options = options;
        });


        this.columns = [
            {
                header:'姓名',
                dataIndex:'name',
                width:75,
                sortable:true,
                filter:{
                    type:'string'
                }
            },
            {
                header:'客户单位',
                dataIndex:'customer_unit_id',
                width:150,
                sortable:true,
                filter:{
                    type:'string'
                }
            },
            {
                header:'英文名',
                dataIndex:'en_name',
                width:100,
                sortable:true,
                filter:{
                    type:'string'
                }
            },
            {
                header:'电子邮件',
                dataIndex:'email',
                width:100,
                sortable:true,
                filter:{
                    type:'string'
                }
            },
            {
                header:'移动电话',
                dataIndex:'mobile',
                width:100,
                sortable:true,
                filter:{
                    type:'string'
                }
            },
            {
                header:'固定电话',
                dataIndex:'tel',
                width:100,
                sortable:true,
                filter:{
                    type:'string'
                }
            },
            {
                header:'传真',
                dataIndex:'fax',
                width:100,
                sortable:true,
                filter:{
                    type:'string'
                }
            },
            {
                header:'QQ/MSN',
                dataIndex:'im',
                width:100,
                sortable:true,
                filter:{
                    type:'string'
                }
            },
            {
                header:'部门',
                dataIndex:'department',
                width:100,
                sortable:true,
                filter:{
                    type:'string'
                }
            },
            {
                header:'职位',
                dataIndex:'position',
                width:100,
                sortable:true,
                filter:{
                    type:'string'
                }
            },
            {
                header:'通信地址',
                dataIndex:'addr',
                minWidth:100,
                flex:1,
                sortable:true,
                filter:{
                    type:'string'
                }
            },
            {
                header:'英文地址',
                dataIndex:'en_addr',
                minWidth:100,
                flex:1,
                sortable:true,
                filter:{
                    type:'string'
                }
            },
            {
                header:'结识方式',
                dataIndex:'lead_id',
                width:100,
                sortable:true,
                filter:{
                    type:'list',
                    phpMode:true,
                    options:[]
                },
                renderer:function (value) {
                    for (var i = 0; i < leadArray.length; i++) {
                        if (leadArray[i]["id"] === value) {
                            return leadArray[i]["name"];
                        }
                    }
                }
            },
            {
                header:'涉及应用',
                dataIndex:'application_ids',
                width:100,
                sortable:true,
                filter:{
                    type:'list',
                    phpMode:true,
                    options:[]
                },
                renderer:function (value) {
                    var display = [];
                    var idArray = value.split("|");
                    for (var i = 0; i < idArray.length; i++) {
                        for (var j = 0; j < applicationArray.length; j++) {
                            if (applicationArray[j]["id"] === Number(idArray[i])) {
                                display.push(applicationArray[j]["name"]);
                            }
                        }
                    }
                    return display.join("、");
                }
            },
            {
                header:'备注',
                dataIndex:'comment',
                width:100,
                sortable:true,
                filter:{
                    type:'string'
                }
            }
        ];

        this.addCustomerButton = Ext.create('Ext.Button', {
            text:'新增客户',
            iconCls:'btn_add',
            action:'addCustomer'
        });
        this.pagingToolbar = Ext.create('Ext.PagingToolbar', {
            store:this.store,
            displayInfo:true,
            border:0,
            minWidth:380
        });

        this.features = [
            {
                ftype:'filters',
                encode:true
            }
        ];

        this.bbar = [this.addCustomerButton, '-', this.pagingToolbar];

        this.callParent(arguments);
    },

    getSelectedItem:function () {
        return this.getSelectionModel().getSelection()[0];
    }
});