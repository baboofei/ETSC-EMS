/**
 * 用于添加客户联系人到“联系人列表”里的小型表单
 * 有“选择客户单位”、“+”和“选择客户”、“+”的组件
 * 还有“移动电话”、“固定电话”和“传真”的显示，可以修改
 */
Ext.define('EIM.view.customer.AddToMiniForm', {
    extend:'Ext.window.Window',
    alias:'widget.customer_add_to_mini_form',

    title:'添加联系人',
    layout:'fit',
    width:300,
    height:206,
    border:0,
    modal:true,

    initComponent:function () {
        this.items = [
            {
                xtype:'form',
                bodyPadding:4,
                layout:'anchor',
                fieldDefaults:EIM_field_defaults,
                items:[
                    {
                        xtype:'hidden',
                        name:'id',
                        fieldLabel:'id'
                    },
                    {
                        xtype:'expandable_customer_unit_combo'
                    },
                    {
                        xtype:'expandable_customer_combo',
                        padding:'5 0'
                    },
                    {
                        xtype:'textfield',
                        fieldLabel:'移动电话',
                        name:'mobile',
                        disabled:true
                    },
                    {
                        xtype:'textfield',
                        fieldLabel:'固定电话',
                        name:'tel',
                        disabled:true
                    },
                    {
                        xtype:'textfield',
                        fieldLabel:'传真',
                        name:'fax',
                        disabled:true
                    }
                ]
            }
        ];

        this.buttons = [
            {
                text:'添加',
                action:'add_to'
            },
            {
                text:'取消',
                scope:this,
                handler:this.close
            }
        ];

        this.callParent(arguments);
    }
});