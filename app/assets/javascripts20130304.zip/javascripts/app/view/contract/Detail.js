Ext.define('EIM.view.contract.Detail', {
    extend:'Ext.form.Panel',
    alias:'widget.contract_detail',

    title:'合同详情',
    bodyPadding:4,
//    frame: true,
    autoScroll:true,
    layout:'border',

    items:[
        {
            xtype:'tabpanel',
            region:'center',
            items:[
                {
                    xtype:'contract_content'
                },
                {
                    xtype:'contract_item_grid'
                },
                {
                    xtype:'collection_panel'
                },
                {
                    xtype:'contract_history_grid'
                }
            ]
        },
        {
            xtype:'form',
            title:'相关联系人',
            id:'contract_info',
            region:'west',
            width:450,
            split:true,
            autoScroll:true,
//        border: 0,
            padding:0,
            layout:'anchor',
            defaults:{anchor:'100%'},
            bodyPadding:4,
//        url: '',//这
            fieldDefaults:EIM_field_defaults,
            items:[
                {
                    xtype:'fieldset',
                    title:'客户信息',
                    collapsible:true,
                    defaultType:'textfield',
                    defaults:{anchor:'100%'},
                    layout:'anchor',
                    items:[
                        {
                            xtype:'expandable_customer_unit_combo',
                            name:'customer_unit_name',
                            fieldLabel:'单位',
                            emptyText:'请输入并选择客户单位',
                            allowBlank:false,
                            hiddenPlus:true
                        },
                        {
                            xtype:'expandable_customer_combo',
                            name:'buyer_customer_name',
                            fieldLabel:'联系人',
                            emptyText:'请选择客户联系人(如采购)',
                            padding:'5 0',
                            allowBlank:false,
                            hiddenPlus:true
                        },
                        {
                            xtype:'expandable_customer_combo',
                            name:'end_user_customer_name',
                            fieldLabel:'使用人',
                            emptyText:'请选择客户最终使用人',
                            allowBlank:false,
                            hiddenPlus:true,
                            disabledPlus:true
                        }
                    ]
                },
                {
                    xtype:'fieldset',
                    title:'进出口公司信息',
                    collapsible:true,
                    defaultType:'textfield',
                    defaults:{anchor:'100%'},
                    layout:'anchor',
                    items:[
                        {
                            xtype:'expandable_business_unit_combo',
                            name:'business_unit_name',
                            fieldLabel:'公司名称',
                            emptyText:'请输入并选择进出口公司',
                            allowBlank:true
                        },
                        {
                            xtype:'expandable_business_contact_combo',
                            name:'business_contact_name',
                            fieldLabel:'联系人',
                            emptyText:'请选择进出口公司联系人',
                            padding:'5 0',
                            allowBlank:true
                        }
                    ]
                },
                {
                    xtype:'fieldset',
                    title:'卖方信息',
                    collapsible:true,
                    defaultType:'textfield',
                    defaults:{anchor:'100%'},
                    layout:'anchor',
                    items:[
                        {
                            xtype:'textfield',
                            name:'our_company_id',
                            fieldLabel:'公司名称',
                            emptyText:'请输入并选择卖方公司'
                        },
                        {
                            xtype:'textfield',
                            name:'signer_user_name',
                            fieldLabel:'工程师',
                            emptyText:'请选择负责此合同的工程师'
                        }
                    ]
//        }],
//        buttons: [{
//            text: '确定',
//            action: 'submit'
                }
            ]
        }
    ],

    initComponent:function () {
        this.callParent(arguments);
    }
});