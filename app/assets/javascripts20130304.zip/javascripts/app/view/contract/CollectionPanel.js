Ext.define('EIM.view.contract.CollectionPanel', {
    extend:'Ext.form.Panel',
    alias:'widget.collection_panel',

    title:'收款信息',
    bodyPadding:4,
    autoScroll:true,
    layout:'anchor',
    fieldDefaults:EIM_field_defaults,

    items:[
        {
            xtype:'container',
            layout:'hbox',
            items:[
                {
                    xtype:'numberfield',
                    fieldLabel:'利润(RMB)',
                    name:'profit',
                    emptyText:'请输入此合同的利润'
                },
                {
                    fieldLabel:'开票状态',
                    name:'invoice',
                    xtype:'textfield',
                    editable:false
                },
                {
                    xtype:'fieldcontainer',
                    fieldLabel:'已收款',
                    items:[
                        {
                            xtype:'progressbar',
                            name:'total_collection',
                            hideLabel:true,
                            id:'total_collection'
                        }
                    ]
                }
            ]
        },
        {
            xtype:'panel',
            layout:'border',
            border:0,
            padding:'5 0 0',
            anchor:'100% -23',
            items:[
                {
                    xtype:'contract_receivable_grid',
                    autoScroll:true,
                    flex:1,
                    padding:'0 2 0 0',
                    region:'center'
                },
                {
                    xtype:'contract_collection_grid',
                    autoScroll:true,
                    flex:1,
                    padding:'0 0 0 2',
                    region:'east'
                }
            ]
        }
    ]
});