Ext.define('EIM.view.contract.Content', {
    extend:'Ext.form.Panel',
    alias:'widget.contract_content',

    title:'合同内容',
    bodyPadding:4,
    autoScroll:true,
    layout:'anchor',
    fieldDefaults:EIM_field_defaults,

    items:[
        {
            xtype:'container',
            layout:'hbox',
            padding:'0 0 5',
            defaults:{
                xtype:'textfield'
            },
            items:[
                {
                    name:'etsc_number',
                    fieldLabel:'东隆合同号'
                },
                {
                    name:'quote_number',
                    fieldLabel:'报价编号'
                },
                {
                    name:'customer_number',
                    fieldLabel:'客户合同号'
                }
            ]
        },
        {
            xtype:'container',
            layout:'hbox',
            padding:'0 0 5',
            defaults:{
                xtype:'textfield'
            },
            items:[
                {
                    name:'summary',
                    fieldLabel:'合同摘要'
                },
                {
                    xtype:'combo',
                    name:'requirement_sort',
                    fieldLabel:'供求类别',
                    store:'dict.RequirementSorts',
                    displayField:'name',
                    editable:false
                },
                {
                    xtype:'combo',
                    name:'status',
                    fieldLabel:'合同状态',
                    store:'dict.ContractStatuses',
                    displayField:'name',
                    editable:false
                }
            ]
        },
        {
            xtype:'container',
            layout:'hbox',
            padding:'0 0 5',
            defaults:{
                xtype:'numberfield'
            },
            items:[
                {
                    xtype:'amount_with_currency',
                    name:'sum',
                    fieldLabel:'合同金额',
                    allQuery:'4'
                },
                {
                    name:'exchange_rate',
                    fieldLabel:'当前汇率'
                },
                {
                    name:'rmb',
                    fieldLabel:'折合人民币'
                }
            ]
        },
        {
            xtype:'container',
            layout:'hbox',
            padding:'0 0 5',
            defaults:{
                xtype:'checkbox'
            },
            items:[
                {
                    xtype:'combo',
                    name:'contract_type',
                    fieldLabel:'合同类别',
                    store:'dict.ContractTypes',
                    displayField:'name',
                    editable:false
                },
                {
                    name:'does_need_install',
                    fieldLabel:'安装需求',
                    boxLabel:'需要安装？'
                },
                {
                    name:'does_receive_lc',
                    fieldLabel:'信用证情况',
                    boxLabel:'收到信用证？'
                },
                {
                    name:'receive_lc_on',
                    xtype:'displayfield',
                    fieldLabel:'收到信用证',
                    value:'#年#月#日',
                    hidden:true
                }
            ]
        },
        {
            xtype: 'combo',
            fieldLabel: '付款方式',
            name: 'pay_mode_id',
            store: 'PayModes',
            mode: 'remote',
            vtype: 'pay_mode',
            valueField: 'id',
            displayField: 'name',
            emptyText: '格式：签合同时付##%|USD###(电汇|信用证)，发货前付##%|USD###(电汇|信用证)，发货后付##%|USD###(电汇|信用证)，验收后付##%|USD###(电汇|信用证)',
            triggerAction: 'query',
            minChars: 1,
            hideTrigger: true
        },
        {
            xtype:'displayfield',
            fieldLabel:'付款方式格式',
            labelWidth:100,
            value:'签合同时付##%|USD###(电汇|信用证)，发货前付##%|USD###(电汇|信用证)，发货后付##%|USD###(电汇|信用证)，验收后付##%|USD###(电汇|信用证)'/*,
         disabled: true*/
        },
        {
            xtype:'textfield',
            fieldLabel:'备注',
            name:'comment'
        }
    ],

    initComponent:function () {
        this.callParent(arguments);
    }
});