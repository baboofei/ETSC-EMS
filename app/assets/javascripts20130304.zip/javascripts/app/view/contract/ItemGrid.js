Ext.define('EIM.view.contract.ItemGrid', {
    extend:'Ext.grid.Panel',
    alias:'widget.contract_item_grid',

    requires:'Ext.ux.grid.FiltersFeature',

    title:'合同项列表',
    store:'ContractItems',
    iconCls:'ttl_grid',
    multiSelect: true,

    initComponent:function () {
        this.columns = [
            {
                header:'产品型号',
                dataIndex:'product_id',
                width:75,
                sortable:false
            },
            {
                header:'产品序列号',
                dataIndex:'serial_number',
                width:75,
                sortable:false
            },
            {
                header: '数量',
                dataIndex: 'quantity',
                width: 50,
                sortable: false
            },
            {
                header: '发货状态',
                dataIndex: 'send_status',
                width: 75
            },
            {
                header: '期望发货时间',
                dataIndex: 'expected_leave_factory_on',
                width: 100,
                renderer:Ext.util.Format.dateRenderer("Y-m-d")
            },
            {
                header: '约定发货时间',
                dataIndex: 'appointed_leave_factory_on',
                width: 100,
                renderer:Ext.util.Format.dateRenderer("Y-m-d")
            },
            {
                header: '实际发货时间',
                dataIndex: 'actually_leave_factory_on',
                width: 100,
                renderer:Ext.util.Format.dateRenderer("Y-m-d")
            },
            {
                header: '离开东隆时间',
                dataIndex: 'leave_etsc_on',
                width: 100,
                renderer:Ext.util.Format.dateRenderer("Y-m-d")
            },
            {
                header: '到达客户时间',
                dataIndex: 'reach_customer_on',
                width: 100,
                renderer:Ext.util.Format.dateRenderer("Y-m-d")
            },
            {
                header: '验收时间',
                dataIndex: 'check_and_accept_on',
                width: 100,
                renderer:Ext.util.Format.dateRenderer("Y-m-d")
            },
            {
                header: '验收情况',
                dataIndex: 'check_and_accept_status',
                width: 75
            },
            {
                header: '质保条款',
                dataIndex: 'term_id',
                flex: 1,
                minWidth: 150
            }
        ];

        this.addContractItemButton = Ext.create('Ext.Button', {
            text:'新增合同项',
            iconCls:'btn_add',
            action:'addContractItem'
        });
        this.editContractItemButton = Ext.create('Ext.Button', {
            text:'修改合同项',
            iconCls:'btn_edit',
            action:'editContractItem',
            disabled: true
        });
        this.divideSendingButton = Ext.create('Ext.Button', {
            text:'分批发货',
            iconCls:'btn_divide',
            action:'divideSending'/*,
            disabled: true*/
        });
        this.batchEditContractItemButton = Ext.create('Ext.Button', {
            text: '批量修改合同项',
            action: 'batchEditContractItem',
//            disabled: true,
            menu: Ext.create('Ext.menu.Menu', {
                items: [
                    {
                        text: '产品数量',
                        action: 'quantity',
                        menu: Ext.create('Ext.menu.Menu', {
                            items: [
                                {
                                    xtype: 'container',
                                    layout: 'hbox',
                                    items:[
                                        {
                                            xtype: 'numberfield',
                                            minValue: 1,
                                            emptyText: '请输入产品数量',
                                            decimalPrecision: 0,
                                            allowBlank: false
                                        },
                                        {
                                            xtype: 'button',
                                            text: '确定'
                                        }
                                    ]
                                }
                            ],
                            title: '产品数量'
                        })
                    },
                    {
                        text: '发货状态',
                        action: 'send_status',
                        menu: Ext.create('Ext.menu.Menu', {
                            items: [
                                {
                                    xtype: 'container',
                                    layout: 'hbox',
                                    items:[
                                        {
                                            xtype: 'combo',
                                            store:'dict.SendStatuses',
                                            displayField:'name',
                                            valueField:'id',
                                            mode:'remote',
                                            emptyText:'请选择发货状态',
                                            triggerAction:'all',
                                            editable: false,
                                            allowBlank: false
                                        },
                                        {
                                            xtype: 'button',
                                            text: '确定'
                                        }
                                    ]
                                }
                            ],
                            title: '发货状态'
                        })
                    },
                    {
                        text: '期望发货时间',
                        action: 'expected_leave_factory',
                        menu: Ext.create('Ext.menu.DatePicker', {
                            title: '期望发货时间'
                        })
                    },
                    {
                        text: '约定发货时间',
                        action: 'appointed_leave_factory',
                        menu: Ext.create('Ext.menu.DatePicker', {
                            title: '约定发货时间'
                        })
                    },
                    {
                        text: '实际发货时间',
                        action: 'actually_leave_factory',
                        menu: Ext.create('Ext.menu.DatePicker', {
                            title: '实际发货时间'
                        })
                    },
                    {
                        text: '离开东隆时间',
                        action: 'leave_etsc',
                        menu: Ext.create('Ext.menu.DatePicker', {
                            title: '离开东隆时间'
                        })
                    },
                    {
                        text: '到达客户时间',
                        action: 'reach_customer',
                        menu: Ext.create('Ext.menu.DatePicker', {
                            title: '到达客户时间'
                        })
                    },
                    {
                        text: '客户验收时间',
                        action: 'check_and_accept',
                        menu: Ext.create('Ext.menu.DatePicker', {
                            title: '客户验收时间'
                        })
                    },
                    {
                        text: '验收状态',
                        action: 'check_and_accept_status',
                        menu: Ext.create('Ext.menu.Menu', {
                            items: [
                                {
                                    xtype: 'container',
                                    layout: 'hbox',
                                    items:[
                                        {
                                            xtype: 'combo',
                                            store:'dict.CheckAndAcceptStatuses',
                                            displayField:'name',
                                            valueField:'id',
                                            mode:'remote',
                                            emptyText:'请选择验收状态',
                                            triggerAction:'all',
                                            editable: false,
                                            allowBlank: false
                                        },
                                        {
                                            xtype: 'button',
                                            text: '确定'
                                        }
                                    ]
                                }
                            ],
                            title: '验收状态'
                        })
                    },
                    {
                        text: '质保条款……',
                        action: 'term'
                    },
                    {
                        text: '分批发货',
                        action: 'divide_sending',
                        menu: Ext.create('Ext.menu.Menu', {
                            items: [
                                {
                                    xtype: 'container',
                                    layout: 'hbox',
                                    items:[
                                        {
                                            xtype: 'numberfield',
                                            minValue: 1,
                                            emptyText: '请输入要分出的数量',
                                            decimalPrecision: 0,
                                            allowBlank: false
                                        },
                                        {
                                            xtype: 'button',
                                            text: '确定'
                                        }
                                    ]
                                }
                            ],
                            title: '分批发货'
                        })
                    }
                ]
            })
        });
        this.pagingToolbar = Ext.create('Ext.PagingToolbar', {
            store:this.store,
            displayInfo:true,
            border:0,
            minWidth:380
        });

        this.bbar = [this.addContractItemButton, this.editContractItemButton, this.divideSendingButton, this.batchEditContractItemButton, this.pagingToolbar];

        this.callParent(arguments);
    },

    getSelectedItem:function () {
        return this.getSelectionModel().getSelection()[0];
    },

    //可多选，加一个“s”的项
    getSelectedItems:function () {
        return this.getSelectionModel().getSelection();
    }
});