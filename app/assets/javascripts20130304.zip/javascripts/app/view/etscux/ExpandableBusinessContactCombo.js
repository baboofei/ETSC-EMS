/**
 * 自定义的组件，包含一个进出口公司联系人的combo框以及一个“+”按钮
 */

Ext.define('EIM.view.etscux.ExpandableBusinessContactCombo', {
    extend:'Ext.container.Container',
    alias:'widget.expandable_business_contact_combo',

    initComponent:function () {
        Ext.tip.QuickTipManager.init();

        this.layout = 'hbox';

        this.items = [
            {
                xtype:'combo',
                fieldLabel:(this.fieldLabel || '联系人'),
                name:'business_contact_id',
                store:'BusinessContacts',
                flex:1,
                displayField:'name',
                valueField:'id',
                emptyText:'请选择进出口公司联系人',
                allowBlank:(this.allowBlank || false), //false,
                editable:false,
//            mode: 'remote',
                triggerAction:'all'
            },
            {
                xtype:'button',
                fieldLabel:'',
                labelWidth:0,
                text:'+',
                action:'add_business_contact',
                tooltip:'新增进出口公司联系人',
                hidden:(this.hiddenPlus || false),
                disabled:(this.disabledPlus || false)
            }
        ];

        this.callParent(arguments);
    }
});