Ext.define('EIM.view.tree.Tree', {
    extend: 'Ext.tree.Panel',
    alias: 'widget.functree',
    autoRender: true,
    
    title: '功能列表',
    id: 'function_tree',
    store: 'Functions',
    autoScroll: false,
    scroll: 'vertical',//垂直的视情况出现，水平的始终不出现(因为宽度是10000……)
    rootVisible: false,
    width: 200,
    
    initComponent: function(){
        this.allLL = [];
        this.allCurrency = [];
        this.callParent(arguments);
    }
});