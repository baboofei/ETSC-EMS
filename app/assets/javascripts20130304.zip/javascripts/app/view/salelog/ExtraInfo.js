/**
 * 备注和操作日期两个组件
 * 因为会有Disable的时候，还会在弹出的别的窗口里用到，所以独立出来
 */
Ext.define('EIM.view.salelog.ExtraInfo', {
    extend: 'Ext.form.Panel',
    alias: 'widget.salelog_extra_info',

    title: '',
    fieldDefaults: EIM_field_defaults,
    bodyPadding: 4,
    border: 0,
    layout: 'hbox',
    items: [{
        xtype: 'textfield',
        name: 'comment',
        fieldLabel: '备注',
        flex: 1
    }, {
        xtype: 'datefield',
        name: 'created_on',
        format: 'Y-m-d',
        fieldLabel: '操作日期',
        emptyText: '请选择此条日志发生的日期',
        value: new Date(),
        flex: 1,
        allowBlank: false
    }],
    buttons: [{
        text: '确定',
        action: 'saveSalelog'
    }]
});