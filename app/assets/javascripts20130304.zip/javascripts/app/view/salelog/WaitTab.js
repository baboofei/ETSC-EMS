Ext.define('EIM.view.salelog.WaitTab', {
    extend: 'Ext.form.Panel',
    alias: 'widget.wait_tab',

    title: '等待',
    border: 0,
    padding: 4,
    layout: 'anchor',
    fieldDefaults: EIM_field_defaults,
    items: [{
        xtype: 'combo',
        fieldLabel: '等待原因',
        name: 'wait_reason',
        store: 'dict.SalecaseWaitReasons',//[[1, "客户上级审批"], [2, "客户内部流程处理"], [3, "免表"], [4, "客户申请资金"], [5, "其他"]],
        valueField: 'id',
        displayField: 'name',
        editable: false,
        allowBlank: false
    }, {
        xtype: 'datefield',
        fieldLabel: '提醒时间',
        name: 'remind_at',
        format: 'Y-m-d',
        value: Ext.Date.add(new Date(), Ext.Date.DAY, 15),
        emptyText: '请选择预计能签署合同的时间(forecast用)'
    }]
});