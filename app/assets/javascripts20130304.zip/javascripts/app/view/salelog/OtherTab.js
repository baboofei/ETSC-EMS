Ext.define('EIM.view.salelog.OtherTab', {
    extend: 'Ext.form.Panel',
    alias: 'widget.other_tab',

    title: '其他',
    border: 0,
    padding: 4,
    layout: 'anchor',
    fieldDefaults: EIM_field_defaults,
    items: [{
        xtype: 'textfield',
        fieldLabel: '详情',
        allowBlank: false
    }]
});