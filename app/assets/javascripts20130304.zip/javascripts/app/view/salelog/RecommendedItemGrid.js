Ext.define('EIM.view.salelog.RecommendedItemGrid', {
    extend: 'Ext.grid.Panel',
    alias: 'widget.recommended_item_grid',

    title: '已推荐项目列表',
    store: 'RecommendedItems',
    iconCls: 'ttl_grid',

    initComponent: function() {
        this.columns = [{
            header: '编号',
            dataIndex: 'id',
            hidden: true
        }, {
            header: '工厂名称',
            dataIndex: 'vendor_unit_name',
            width: 150
        }, {
            header: '产品型号',
            dataIndex: 'product_model',
            width: 150
        }, {
            header: '指标',
            dataIndex: 'parameter',
            flex: 1
        }, {
            header: '客户需求',
            dataIndex: 'customer_requirement',
            width: 150
        }];

        this.addQuotedItemButton = Ext.create('Ext.Button', {
            text: '新增推荐项目',
            iconCls: 'btn_add',
            action: 'addRecommendItem'
        });
        this.editQuotedItemButton = Ext.create('Ext.Button', {
            text: '修改推荐项目',
            iconCls: 'btn_edit',
            action: 'editRecommendedItem',
            disabled: true
        });
        this.pagingToolbar = Ext.create('Ext.PagingToolbar', {
            store: this.store,
            displayInfo: true,
            border: 0,
            minWidth: 380
        });

        this.bbar = [this.addQuotedItemButton, this.editQuotedItemButton, '-', this.pagingToolbar];

        this.callParent(arguments);
    },

    getSelectedItem: function() {
        return this.getSelectionModel().getSelection()[0];
    },

    enableRecordButtons: function() {
        this.editQuotedItemButton.enable();
    },
    disableRecordButtons: function() {
        this.editQuotedItemButton.disabled();
    }
});